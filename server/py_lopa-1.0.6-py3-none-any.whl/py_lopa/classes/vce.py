import csv
import math
import random
import numpy as np
import pandas as pd
from scipy.interpolate import griddata
from scipy import integrate
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

from pypws.calculations import DispersionCalculation, LateExplosionCalculation, DistancesAndFootprintsToConcentrationLevelsCalculation
from pypws.entities import ExplosionConfinedVolume, DispersionOutputConfig, ExplosionOutputConfig, ExplosionParameters
from pypws.enums import Resolution, SpecialConcentration, MEConfinedMethod, ResultCode

from py_lopa.calcs import helpers
from py_lopa.calcs.integrator import Integrator

class VCE:

    def __init__(self, phast_dispersion = None, flatten = None, save_pickles = False) -> None:
        self.zxys_df = {}
        self.flatten = flatten
        self.phast_dispersion = phast_dispersion
        self.dispersionCalculation = phast_dispersion.dispersionCalculation
        self.mi = phast_dispersion.mi
        if save_pickles:
            self.save_pickles()
        self.sigma_y_consts = {}
        self.sigma_z_consts = {}
        self.targ_concs = []
        if self.phast_dispersion is not None:
            lfl = self.phast_dispersion.ep_conc
            self.targ_concs = [lfl]
        self.flammable_mass_g = None
        self.flammable_mass_results = None
        self.max_dw_extent = None
        self.flammable_envelope_list_of_dicts = []
        self.flammable_envelope_df = {}
    
    def get_overall_flammable_envelope_and_maximum_downwind_extent(self):
        self.get_conc_targets_between_lfl_and_pure_conc()
        resp = self.run_dispersion_model_inside_flammable_envelope()
        
        if resp != ResultCode.SUCCESS:
            self.phast_dispersion.mi.LOG_HANDLER('VCE model did not complete successfully')
            return
        self.phast_dispersion.mi.LOG_HANDLER('it worked.  from vce')

        self.parse_flam_env_contour_points()

        return {
            'flammable_envelope_list_of_dicts': self.flammable_envelope_list_of_dicts,
            'maximum_downwind_extent': self.max_dw_extent,
        }
    
    def save_pickles(self):
        helpers.save_object_as_pickle_return_path_and_file_name(self.phast_dispersion, descr='p_disp', out_dir='../vce_testing/', use_time_stamp=False)
    
    def get_conc_targets_between_lfl_and_pure_conc(self):
        # concentrations exponentially increasing from lfl to pure conc over 6 values:  1e6 = lfl * factor^6 
        lfl = self.targ_concs[0]
        self.targ_concs = np.linspace(lfl, 0.99, 10).tolist()
        low_end_concs = np.linspace(lfl, self.targ_concs[1], 10).tolist()
        self.targ_concs.extend(low_end_concs)
        self.targ_concs.sort()
        

    def run_dispersion_model_inside_flammable_envelope(self):
        self.phast_dispersion.run_footprint_models_for_vce(self.targ_concs)

        return self.phast_dispersion.distancesAndFootprintsCalc.result_code
    
    def parse_flam_env_contour_points(self):
        dists_and_concs:DistancesAndFootprintsToConcentrationLevelsCalculation = self.phast_dispersion.distancesAndFootprintsCalc
        n_contour_points = dists_and_concs.n_contour_points
        data = []
        cp_idx_start = 0
        cps = dists_and_concs.contour_points
        for i in range(len(n_contour_points)):
            if n_contour_points[i] == 0:
                continue
            dispOutputCfg:DispersionOutputConfig = dists_and_concs.dispersion_output_configs[i]
            conc = dispOutputCfg.concentration
            if conc is None:
                conc = 0
            cp_count = n_contour_points[i]
            curr_cp_range = cps[cp_idx_start:cp_idx_start+cp_count]
            for cp in curr_cp_range:
                x = cp.x
                y = cp.y
                z = cp.z
                data.append({
                    'x': x,
                    'y': y,
                    'z': z,
                    'conc_ppm': conc * 1e6
                })
            cp_idx_start += cp_count
        
        df = pd.DataFrame(data)
        df = df[(df['x'] > -10000) & (df['x'] < 10000)]

        # concGm3 = concPpm * mWt / 24450
        flash_data = self.phast_dispersion.chems.flash_data
        ys = np.array(flash_data['ys'])
        mws = np.array(flash_data['mws'])
        ave_mw_vap = ys.dot(mws.T)
        df['conc_g_m3'] = df['conc_ppm'] * ave_mw_vap / 24450
        self.flammable_envelope_df = df
        self.flammable_envelope_list_of_dicts = df.to_dict(orient='records')
        x_min = df['x'].min()
        x_max = df['x'].max()
        self.max_dw_extent=max(abs(x_min), abs(x_max))

    def get_flammable_mass(self, x_min = None, x_max = None, y_min = None, y_max = None, z_min = None, z_max = None, flammable_envelope_list_of_dicts = None):
        if flammable_envelope_list_of_dicts is None:
            flammable_envelope_df = self.flammable_envelope_df
        else:
            flammable_envelope_df = pd.DataFrame(flammable_envelope_list_of_dicts)

        integrator = Integrator()
        integrator.load_data(flammable_envelope_df)
        results = integrator.integrate(x_min=x_min, x_max=x_max, y_min=y_min, y_max=y_max, z_min=z_min, z_max=z_max)
        self.flammable_mass_g = results['total_mass_g']
        self.flammable_mass_results = results
        return {
            'flammable_mass_g': self.flammable_mass_g,
            'flammable_mass_results': self.flammable_mass_results,
        }

    def plot_flammable_envelope(self):
        df = self.flammable_envelope_df
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')

        sc = ax.scatter(df['x'], df['y'], df['z'], c=df['conc_ppm'], cmap='viridis')

        plt.colorbar(sc)
        ax.set_xlabel('X Axis')
        ax.set_ylabel('Y Axis')
        ax.set_zlabel('Z Axis')

        plt.show()