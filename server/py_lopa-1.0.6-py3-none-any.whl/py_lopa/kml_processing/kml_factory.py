import io
from lxml import etree as ET
import pandas as pd
import numpy as np

from py_lopa.calcs import helpers
from py_lopa.calcs.consts import Consts
from py_lopa.kml_processing import kml_utils
from py_lopa.data.color_data import Color_Data

cd = Consts().CONSEQUENCE_DATA

class KML_Factory:

    def __init__(self, points = [], description = '') -> None:
        self.points = points
        self.description = description
    
    def gen_kml_bytestr(self, conc_lat_long_alt_radial_circle_flattened_df, conc_alt_wd_lon_lat_flattened_df, haz, wx_enum, dur_min):

        # conc_lat_long_alt_dicts.append({
        #     cd.OUTPUT_CONCENTRATION_USED_PPM_STR: conc_ppm_str,
        #     cd.LONG_LAT_ALTITUDE: points_for_kml
        # })

        df = conc_lat_long_alt_radial_circle_flattened_df
        kml_doc = ET.Element('kml', xmlns='http://www.opengis.net/kml/2.2')
        document = ET.SubElement(kml_doc, 'Document')
        name = ET.SubElement(document, 'name').text = f'Weather:  {wx_enum}.  Hazard Type: {haz}.  Duration: {dur_min} min.'
        if len(conc_lat_long_alt_radial_circle_flattened_df) == 0 and len(conc_alt_wd_lon_lat_flattened_df) == 0:
            return ET.tostring(kml_doc, pretty_print=True)
        
        self.apply_color_styles(document)

        
        grouped = df.groupby(cd.ALTITUDE)
        for z, conc_radial_circle_plume_lat_long_df in grouped:
            folder_alt = ET.SubElement(document, 'Folder') 
            name = ET.SubElement(folder_alt, 'name').text = f'Elevation: {z} meter(s)'
            if len(conc_radial_circle_plume_lat_long_df) == 0:
                continue
            self.populate_vulnerability_plot(folder_alt, conc_radial_circle_plume_lat_long_df)
            conc_wd_lon_lat_df = conc_alt_wd_lon_lat_flattened_df[conc_alt_wd_lon_lat_flattened_df[cd.ALTITUDE] == z]
            if len(conc_alt_wd_lon_lat_flattened_df) == 0:
                continue
            self.populate_plume_extent_data(folder_alt, conc_wd_lon_lat_df)
        
        return ET.tostring(kml_doc, pretty_print=True)

    def apply_color_styles(self, folder):
        
        for col_dict in Color_Data.all_color_dicts:
            style = ET.SubElement(folder, 'Style')
            style.attrib['id'] = col_dict['id']
            line_style = ET.SubElement(style, 'LineStyle')
            color = ET.SubElement(line_style, 'color').text = col_dict['line_color']
            width = ET.SubElement(line_style, 'width').text = '5'
            poly_style = ET.SubElement(style, 'PolyStyle')
            color = ET.SubElement(poly_style, 'color').text = col_dict['poly_color']
        

    def populate_vulnerability_plot(self, folder_alt, conc_radial_circle_plume_lat_long_df):
        df = conc_radial_circle_plume_lat_long_df
        
        folder_vuln = ET.SubElement(folder_alt, 'Folder')
        name = ET.SubElement(folder_vuln, 'name').text = 'Vulnerability Plot'
        i = -1
        for _, row in df.iterrows():
            i += 1
            conc = row[cd.OUTPUT_CONCENTRATION_USED_PPM_STR]
            radials = row[cd.RADIAL_CIRCLE_DICT]
            inner = radials[cd.INNER_BOUNDS]
            outer = radials[cd.OUTER_BOUNDS]
            col = Color_Data.all_color_dicts[i]
            col_style_url = col['id']
            self.get_placemark(folder=folder_vuln, name=conc, outer_bounds_df=outer, inner_bounds_df=inner, col_style_url=col_style_url)
            
    
    def populate_plume_extent_data(self, folder_alt, conc_wd_lon_lat):
        df = conc_wd_lon_lat
        
        folder_wds = ET.SubElement(folder_alt, 'Folder')
        name = ET.SubElement(folder_wds, 'name').text = 'Plume Impact by Wind Direction'
        grouped = df.groupby(cd.WIND_DIRECTION)
        for wd, grouped_by_wd in grouped:
            folder_wd = ET.SubElement(folder_wds, 'Folder')
            name = ET.SubElement(folder_wd, 'name').text = f'Wind from {wd:.2f} degrees'
            i = -1
            for _, row in grouped_by_wd.iterrows():
                i += 1
                conc = row[cd.OUTPUT_CONCENTRATION_USED_PPM_STR]
                ll = row[cd.LONG_LAT]
                ll = ll[ll[:,3].argsort()]
                ll_df = pd.DataFrame(ll, columns=['lon', 'lat', 'z', 'angle'])
                col = Color_Data.all_color_dicts[i]
                col_style_url = col['id']
                self.get_placemark(folder=folder_wd, name=conc, outer_bounds_df=ll_df, inner_bounds_df={}, col_style_url=col_style_url)
    

    def get_placemark(self, folder, name, outer_bounds_df, inner_bounds_df, col_style_url):
        placemark = ET.SubElement(folder, 'Placemark')
        name = ET.SubElement(placemark, 'name').text = name
        col_style_url = ET.SubElement(placemark, 'styleUrl').text = f'#{col_style_url}'
        polygon = ET.SubElement(placemark, 'Polygon')
        altitude_mode = ET.SubElement(polygon, 'altitudeMode').text = 'clampToGround'
        bounds_dict = {
            'innerBoundaryIs': inner_bounds_df,
            'outerBoundaryIs': outer_bounds_df
        }

        for bound_text, bounds_df in bounds_dict.items():
            self.apply_inner_and_outer_bounds(bound_text=bound_text, bounds_df=bounds_df, polygon=polygon)

    def apply_inner_and_outer_bounds(self, bound_text, bounds_df, polygon):
        
        if len(bounds_df) == 0:
            return

        boundary_is = ET.SubElement(polygon, bound_text)
        linear_ring = ET.SubElement(boundary_is, 'LinearRing')

        coords = bounds_df.values
        # coords = coords[coords[:,1].argsort()]
        coords_str = ''
        for row in coords:
            coords_str += f'{row[0]},{row[1]},{row[2]}\n'

        # dict and list comprehension would write coords randomly.  output kml looked quite jagged.
        # for some reason, adding a line break to end of f-string would force list comprehension to write points in order.
        # however, just for sanity, sticking with 'row in' method.
        # coords_str = [f'{row[0]},{row[1]},{row[2]}\n' for row in coords]

        coordinates = ET.SubElement(linear_ring, 'coordinates').text = coords_str
    
    def get_combined_disp_kml_bytestrs_return_one_str(self, disp_dicts):

        kml_doc = ET.Element('kml', xmlns='http://www.opengis.net/kml/2.2')
        document = ET.SubElement(kml_doc, 'Document')

        for disp_dict in disp_dicts:
            data_str = disp_dict[cd.OUTPUT_DISPERSION_KML_BYTESTR]
            data_bytes = io.BytesIO(data_str)
            data = ET.parse(data_bytes).getroot()
            doc = data.find('./{http://www.opengis.net/kml/2.2}Document')
            document.append(doc)
        
        return ET.tostring(kml_doc, pretty_print=True)
