import os
import copy
import pickle
import pandas as pd

from pypws.calculations import UserDefinedSourceLinkedRunCalculation, VesselLeakCalculation
from pypws.entities import DispersionOutputConfig
from pypws.enums import Phase, ResultCode, SpecialConcentration, Resolution

from py_lopa.classes.bldg_heights_to_eval import Bldg_Heights_To_Evaluate
from py_lopa.phast_io import phast_prep
from py_lopa.calcs.consts import Consts, Wx_Enum

cd = Consts().CONSEQUENCE_DATA


class UDS:

    def __init__(self, discharge, chems, room_vol_m3, airflow_m3_s, vent_height_m, vent_diam_m, vent_angle_rad, wx_enum = Wx_Enum.NIGHT):
        self.vlc:VesselLeakCalculation = discharge.vesselLeakCalculation
        self.chems = chems
        self.mi = discharge.mi
        self.room_vol_m3 = room_vol_m3
        self.airflow_m3_s = airflow_m3_s
        self.vent_diam_m = vent_diam_m
        self.vent_height_m = vent_height_m
        self.vent_angle_rad = vent_angle_rad
        self.wx_enum = wx_enum
        self.disp_output_configs = []
    
    def run(self):
        self.prep_elevations_to_eval()
        self.prep_weather_and_substrate()
        self.populate_set_uds_for_linked_run()
        self.run_uds_linked_calcs()
        self.parse_model_output()

    def prep_elevations_to_eval(self):

        bh = Bldg_Heights_To_Evaluate(mi = self.mi)
        self.study_bldg_hts = bh.calc_elevs()

    def prep_weather_and_substrate(self):
        self.weather = phast_prep.prep_weather(wx_enum=self.wx_enum)
        self.substrate = phast_prep.prep_substrate(mi=self.mi)

    def prep_disp_output_configs(self):
        self.flam_disp_output_cfgs = []
        self.tox_disp_output_cfgs = []

        for elev_m in self.study_bldg_hts:
            disp_output_cfg:DispersionOutputConfig = DispersionOutputConfig()
            disp_output_cfg.resolution = Resolution.MEDIUM
            disp_output_cfg.specialConcentration = SpecialConcentration.NOT_DEFINED
            disp_output_cfg.downwindDistance = self.mi.CONSEQUENCE_DISTS[cd.KEYS_MAX_DIST_M]
            disp_output_cfg.elevation = elev_m


            for haz, valid in self.mi.VALID_HAZARDS.items():
                
                if valid:
                    if haz == cd.HAZARD_TYPE_INHALATION:
                        for i in range(1,4):
                            disp_output_cfg.concentration = self.chems.inhalation_locs[i]
                            self.tox_disp_output_cfgs.append(copy.deepcopy(disp_output_cfg))
                        
                    if haz == cd.HAZARD_TYPE_FLASH_FIRE:
                        for i in range(1,3):
                            disp_output_cfg.concentration = self.chems.flam_loc_fracts[i]
                            disp_output_cfg.lflFractionValue = 0.25
                            self.flam_disp_output_cfgs.append(copy.deepcopy(disp_output_cfg))
            

    
    def populate_set_uds_for_linked_run(self):
        self.uds_linked_run_calc = UserDefinedSourceLinkedRunCalculation()

        self.uds_linked_run_calc.material = self.vlc.exitMaterial
        self.uds_linked_run_calc.dischargeRecords = self.vlc.dischargeRecords
        self.uds_linked_run_calc.dischargeParameters = self.vlc.dischargeParameters

        self.uds_linked_run_calc.substrate = self.substrate
        self.uds_linked_run_calc.weather = self.weather

        self.prep_disp_output_configs()

        dr_0 = self.vlc.dischargeRecords[0]

        self.uds_linked_run_calc.material = self.vlc.exitMaterial
        
        dres = self.vlc.dischargeResult

        mass_released_kg = dres.releaseMass
        durn_s = mass_released_kg / dr_0.massFlow

        self.uds_linked_run_calc.releaseDuration = durn_s

        lf = dr_0.finalState.liquidFraction
        phase:Phase = Phase.UNSET

        if lf == 1:
            phase = Phase.LIQUID
        elif lf == 0:
            phase = Phase.VAPOUR
        else:
            phase = Phase.TWO_PHASE
        
        self.uds_linked_run_calc.phaseToBeReleased = phase

        
        vol_rate_m3_s = self.airflow_m3_s
        
        P = 1 # atm
        V = vol_rate_m3_s
        R = 0.0820575 # atm.m3/kmol/deg K
        T = 298.15 # deg K
        
        n = P * V / R / T
        
        # chems_df = copy.deepcopy(self.discharge.chems.releasing_stream_chem_data)
        # chems_df['masses'] = chems_df['mw'] * chems_df['mole_fraction']
        # ave_mw = chems_df['masses'].sum()

        airflow_mass_rate_kg_s = n * 28.96

        dres.preDilutionAirRate = airflow_mass_rate_kg_s
        dres.height = self.vent_height_m
        dres.angle = self.vent_angle_rad
        dres.holeDiameter = self.vent_diam_m


        self.uds_linked_run_calc.dischargeResult = dres

        self.uds_linked_run_calc.dispersionToxicOutputConfigs = self.tox_disp_output_cfgs
        self.uds_linked_run_calc.dispersionFlamOutputConfigs = self.flam_disp_output_cfgs

    
    def run_uds_linked_calcs(self):

        resultCode = ResultCode.FAIL_EXECUTION
        for i in range(5):
            try:
                resultCode = self.uds_linked_run_calc.run()

            except:
                continue
            break
        
        if resultCode != ResultCode.SUCCESS:

            self.uds_linked_run_calc.print_messages()

            raise Exception('Error in User Defined Source')
    
    def parse_model_output(self):

        apple = 1