import copy
import pandas as pd
import numpy as np
import datetime
from datetime import datetime as d_time

from thermo import ChemicalConstantsPackage, CEOSGas, CEOSLiquid, PRMIX, FlashVL, FlashPureVLS
from thermo.interaction_parameters import IPDB
from thermo.stream import EquilibriumStream

from pypws.calculations import FlashCalculation
from pypws.enums import ResultCode, Phase

from py_lopa.phast_io import phast_prep
from py_lopa.calcs import helpers
from py_lopa.calcs.consts import Consts
from py_lopa.calcs import thermo_pio
from py_lopa.data.exception_enum import Exception_Enum
from py_lopa.classes.source_input import Source_Input
from py_lopa.classes.solver import Solver
from py_lopa.phast_io import phast_prep
from py_lopa.calcs.energy_balance import Energy_Balance

# import statement for model_controller is at bottom (workaround for recursive calling)

cd = Consts().CONSEQUENCE_DATA
p_targ_psig = 0.1

class Indoor_Modeling_3:

    def __init__(self, phast_disp, debug = False):
        
        self.mol_fracts_and_mass_rate_by_time_df = None
        # get all the required parameters from phast_discharge
        self.phast_disp = phast_disp
        self.debug = debug
        if self.debug:
            helpers.save_object_as_pickle_return_path_and_file_name(self.phast_disp, 'phast_disp')
        self.chems = self.phast_disp.chems
        self.mi = self.phast_disp.mi
        self.subcooled_release_in_building = True
        self.flash_pws = self.phast_disp.flashresult
        self.temp_k = self.phast_disp.dispersionCalculation.discharge_records[0].final_state.temperature
        self.press_pa = self.phast_disp.dispersionCalculation.discharge_records[0].final_state.pressure

        # ideal flash calc performed by py_lopa to get phase comps.
        # this is not as detailed as the pws flash calc, but that is missing composition data.
        self.flash_py_lopa = self.chems.flash_data

        # this indoor_modeling class will be launching its own 
        # model_controller.  when launched, this will specify that 
        # model_controller should only evaluate the one release duration associated with this
        # dispersion.

        # short indoor release durations will be modeled for exfiltration over a 15 minute period

        rel_durn_sec = max(self.phast_disp.release_duration_sec, 900)
        
        self.release_durations_to_model_sec = [rel_durn_sec]
        self.chem_mix_no_air = copy.deepcopy(self.mi.CHEM_MIX)
        self.comp_no_air = copy.deepcopy(self.mi.COMPOSITION)
        self.air_cas_no = '132259-10-0'
        # self.air_cas_no = '7727-37-9' # substituting nitrogen for air.  thermo.py not working with air cas no.
        self.chem_mix_with_air = self.chem_mix_no_air + [self.air_cas_no]

        # get model inputs as originally received from user input 
        # (stored as model_controller property)
        self.inputs = copy.deepcopy(self.phast_disp.mc.inputs)
        self.mws = helpers.get_mws(chem_mix=self.chem_mix_no_air, cheminfo=self.chems.cheminfo)
        mw_air = 28.96
        # mw_air = 28.0134 # substituting with nitrogen.
        self.mws_with_air = copy.deepcopy(self.mws)
        self.mws_with_air.append(mw_air)
        self.pool_temp_K = 298.15
        self.vlc = self.phast_disp.phast_discharge.vesselLeakCalculation
        self.tot_mass_flow_kg_s = self.phast_disp.dispersionCalculation.discharge_records[0].mass_flow
        self.liquid_fraction_mass = self.vlc.discharge_records[0].final_state.liquid_fraction
        self.cat_release = self.mi.CATASTROPHIC_VESSEL_FAILURE
        self.data_for_catastrophic_release_model = {}
        self.pws_material_for_dew_point_pressure_calc = None

    
    def run(self):

        self.get_phase_compositions_of_discharge_material()
        self.get_airflow_rate()

        if self.mi.CATASTROPHIC_VESSEL_FAILURE:
            self.catastrophic_release()
        else:
            self.steady_state_release()

        self.update_input_parameters()

        if self.debug:
            helpers.save_object_as_pickle_return_path_and_file_name(self, 'im_3')

        self.launch_model_controller()

    def steady_state_release(self):
        self.mass_balance()
        self.energy_balance()

    def catastrophic_release(self):
        self.mass_balance_cat_failure()
        self.energy_balance_cat_failure()

    def mass_balance(self):
        
        self.get_vapor_rates()
        self.get_liquid_rates_discharged_and_spilled_to_pool_and_aerosol()
        self.source_inputs = [self.vapor_data, self.air_data, self.pool_evap_data, self.aerosol_data]
        self.merge_streams()
    
    def mass_balance_cat_failure(self):

        self.get_pool_data()
        self.get_release_mass()
        self.get_starting_mass_of_air_in_room()
        self.adjust_masses_and_get_aerosol_and_vapor_rates()
        self.build_pseudo_source_inputs_based_on_masses()
        self.merge_streams()

    def get_phase_compositions_of_discharge_material(self):

        data = thermo_pio.get_vapor_phase_comp_and_flash_calc_from_discharge_result(vessel_leak_calc=self.vlc, chems=self.chems, mi=self.mi)
        
        self.temp_k = data['discharge_temp_c'] + 273.15
        self.discharge_flash_data = data['flash_data']

        liquid_mol_fracts = self.discharge_flash_data['xs']
        self.liquid_mass_fracts = helpers.mass_fracts_from_mol_fracts(liquid_mol_fracts, self.mws)
        vapor_mol_fracts = self.discharge_flash_data['ys']
        self.vapor_mass_fracts = helpers.mass_fracts_from_mol_fracts(vapor_mol_fracts, self.mws)
        
    def get_liquid_rates_discharged_and_spilled_to_pool_and_aerosol(self):

        liq_rate_kg_s = self.liquid_fraction_mass * self.tot_mass_flow_kg_s
        self.get_pool_data()
        aerosol_rate_kg_s = max(liq_rate_kg_s - self.rainout_data.mass_flow_kg_s,0)

        # assuming that the flash is at an equilibrium point, lowering the aerosol temp by a small amount to force energy balance to see as liquid
        aerosol_temp_k = self.temp_k - 0.01
        self.aerosol_data = Source_Input(description='aerosol', mass_flow_kg_s=aerosol_rate_kg_s, mass_composition=self.liquid_mass_fracts, chem_mix=self.chem_mix_no_air, temp_k=aerosol_temp_k, cheminfo = self.chems.cheminfo)
        self.aerosol_data.populate_flash_results()
        

    def get_pool_data(self):
        
        pool_recs = []
        pool_data = []
        rainout_rate_kg_s = 0
        pool_evap_temp_k = self.temp_k
        pool_evap_rate_kg_s = 0

        # mass to pool is used for catastrohpic release, where the total volume of the room is mixed with total volume of the release
        # mass to pool will be subtracted from that mixture and then added dynamically from the pool evap input.
        mass_to_pool_kg = 0

        if hasattr(self.phast_disp.dispersionCalculation, 'pool_records'):
            pool_recs = self.phast_disp.dispersionCalculation.pool_records

        if len(pool_recs) > 0:
            pool_data = [{'time_sec': x.time, 'spill_rate_kg_per_sec': x.spill_rate, 'vap_rate_kg_per_sec':x.vapourisation_rate, 'temp_k': x.temperature, 'mass_spilled_kg': x.mass_spilt} for x in pool_recs]
                
        pool_data_df = pd.DataFrame(pool_data)

        if len(pool_data_df) > 0:
            rainout_rate_kg_s = pool_data_df['spill_rate_kg_per_sec'].max()
            pool_evap_temp_k = pool_data_df['temp_k'].max()
            pool_evap_rate_kg_s = pool_data_df['vap_rate_kg_per_sec'].max()
            mass_to_pool_kg = pool_data_df['mass_spilled_kg'].max()

        pool_evap_flash_data = thermo_pio.ideal_flash_calc_get_vf_xs_ys_mol_basis(chem_mix=self.chem_mix_no_air, mws = self.mws, overall_molfs=self.discharge_flash_data['xs'], temp_K=pool_evap_temp_k, press_Pa=101325, cheminfo=self.chems.cheminfo)
        pool_evap_ys = pool_evap_flash_data['ys']

        # for subcooled liquids, the vapor over the pool will be in equilibrium with the liquid.  
        # its total vapor pressure will be less than zero.  in this case, the pressure for the source input will be lower than atmospheric
        # this will maintain the pool evaporation in a vapor state
        press_pa = 101325
        if sum(pool_evap_ys) == 0:
            # data = thermo_pio.get_dew_point_press_pa_return_press_pa_and_flash_data(py_lopa_flash_data=pool_evap_flash_data, cheminfo = self.chems.cheminfo, mat = self.pws_material_for_dew_point_pressure_calc)
            # pool_evap_flash_data = data['flash_data']
            # press_pa = pool_evap_flash_data['press_pa']
            pool_evap_ys = pool_evap_flash_data['k_times_zi']
            # self.pws_material_for_dew_point_pressure_calc = data['pws_material']

        pool_evap_mass_fracts = helpers.mass_fracts_from_mol_fracts(pool_evap_ys, self.mws)
        self.pool_evap_data = Source_Input(description = 'pool_evaporation', mass_flow_kg_s=pool_evap_rate_kg_s, mass_composition=pool_evap_mass_fracts, temp_k = pool_evap_temp_k, chem_mix = self.chem_mix_no_air, cheminfo = self.chems.cheminfo, press_pa = press_pa)
        self.pool_evap_data.populate_flash_results(flash_calc = pool_evap_flash_data)
        self.rainout_data = Source_Input(description = 'rainout', mass_flow_kg_s=rainout_rate_kg_s, mass_composition=self.liquid_mass_fracts, temp_k=self.temp_k, chem_mix=self.chem_mix_no_air)
        
        self.data_for_catastrophic_release_model['pool_data_df'] = pool_data_df
        self.data_for_catastrophic_release_model['mass_to_pool_kg'] = mass_to_pool_kg
        
        
        if self.mi.CATASTROPHIC_VESSEL_FAILURE:
            dynamic_data = [{
                'time_sec': 0,
                'vap_rate_kg_per_sec': 0,
                'temp_k': 298.15,
                'liq_rate_kg_per_sec': 0
            }]
            if len(pool_data_df) > 0:
                dynamic_data = pool_data_df[['time_sec', 'vap_rate_kg_per_sec', 'temp_k']]
                dynamic_data['liq_rate_kg_per_sec'] = 0
            self.pool_evap_data.dynamic_df = dynamic_data



    def get_release_mass(self):
        
        disch = self.phast_disp.phast_discharge
        rho_kg_m3 = disch.flashresult.total_fluid_density
        vessel = disch.vessel
        vessel_diam_m = vessel.diameter
        vessel_ht_m = vessel.height
        vessel_vol_m3 = np.pi * vessel_diam_m**2 / 4 * vessel_ht_m
        self.data_for_catastrophic_release_model['release_mass_kg'] = vessel_vol_m3 * rho_kg_m3
    
    def get_starting_mass_of_air_in_room(self):

        room_vol_m3 = self.mi.ROOM_VOL_M3
        mw_air =  28.96
        # mw_air = 28.0134 # substituting nitrogen for air.  thermo.py not working with air cas no.
        r_atm_m3_kmol_deg_k = 0.0820575
        air_t_deg_k = 298.15
        p_atm = 1
        kmol_air = p_atm * room_vol_m3 / r_atm_m3_kmol_deg_k / air_t_deg_k
        mass_air_kg = kmol_air * mw_air
        self.data_for_catastrophic_release_model['mass_air_kg'] = mass_air_kg
    
    def adjust_masses_and_get_aerosol_and_vapor_rates(self):

        release_mass_kg = self.data_for_catastrophic_release_model['release_mass_kg']
        mass_to_pool_kg = self.data_for_catastrophic_release_model['mass_to_pool_kg']
        liquid_mass_kg = release_mass_kg * self.liquid_fraction_mass
        vapor_mass_kg = release_mass_kg * (1 - self.liquid_fraction_mass)
        aerosol_mass_kg = liquid_mass_kg - mass_to_pool_kg
        aerosol_mass_kg = max(0, aerosol_mass_kg)


        # analyzing balance of vapor/aerosol with air.  pool mass will incorporate as evaporation
        release_mass_kg -= mass_to_pool_kg
        release_mass_kg = max(0, release_mass_kg)
        self.data_for_catastrophic_release_model['release_mass_kg'] = release_mass_kg

        # once balance temp is solved, need to determine increase in room pressure from release.  
        # if negligible, then reduce air volume in room by release volume.  
        # if not negligible, then release volume of hazardous material mixed with air that will equilibrate room.

        # for situations where the volume released (moles) greatly increase the total moles in the room,
        # run a discharge model based on increased pressure and mixing to determine rate across opening
        # compare to airflow rate (forced ACH).  if not much greater, than just run the dispersion as normal.
        # if it is significant, then run separate model for impact due to sudden discharge of material.

        # mass_air_kg = self.data_for_catastrophic_release_model['mass_air_kg']
        # mass_air_kg -= release_mass_kg
        # mass_air_kg = max(0, mass_air_kg)
        # self.data_for_catastrophic_release_model['mass_air_kg'] = mass_air_kg

        self.data_for_catastrophic_release_model['aerosol_mass_kg'] = aerosol_mass_kg
        self.data_for_catastrophic_release_model['vapor_mass_kg'] = vapor_mass_kg
    
    def build_pseudo_source_inputs_based_on_masses(self):

        mass_air_kg = self.data_for_catastrophic_release_model['mass_air_kg']
        self.air_room_si = Source_Input(description='air_mass_in_bldg', mass_flow_kg_s=mass_air_kg, mass_composition=[1], temp_k=298.15, chem_mix=[self.air_cas_no], cheminfo=self.chems.cheminfo)
        dynamic_data = [{
            'time_sec': 0,
            'vap_rate_kg_per_sec': self.air_data.mass_flow_kg_s,
            'liq_rate_kg_per_sec': 0,
            'temp_k': 298.15
        }]
        dyn_data_df = pd.DataFrame(dynamic_data)
        self.air_room_si.dynamic_df = dyn_data_df


        vapor_mass_kg = self.data_for_catastrophic_release_model['vapor_mass_kg']
        vapor_temp_k = self.temp_k + 0.01
        vapor_mass_si = Source_Input(description='vapor_mass', mass_flow_kg_s=vapor_mass_kg, mass_composition=self.vapor_mass_fracts, chem_mix = self.chem_mix_no_air, temp_k=vapor_temp_k, cheminfo=self.chems.cheminfo)

        aerosol_mass_kg = self.data_for_catastrophic_release_model['aerosol_mass_kg']
        aerosol_temp_k = self.temp_k - 0.01
        aerosol_mass_si = Source_Input(description='aerosol_mass', mass_flow_kg_s=aerosol_mass_kg, mass_composition=self.liquid_mass_fracts, chem_mix=self.chem_mix_no_air, temp_k=aerosol_temp_k, cheminfo=self.chems.cheminfo)

        self.source_inputs = [
            self.air_room_si,
            vapor_mass_si,
            aerosol_mass_si
        ]

        self.source_inputs_dynamic = [
            self.air_room_si,
            self.pool_evap_data,
        ]

        si:Source_Input
        for si in self.source_inputs:
            si.populate_flash_results()

    def get_airflow_rate(self):

        # get air rate thru production area
        room_vol_m3 = self.mi.ROOM_VOL_M3
        production_area_ach = self.mi.PRODUCTION_AREA_ACH
        air_vol_rate_m3_hr = room_vol_m3 * production_area_ach
        mw_air =  28.96
        # mw_air = 28.0134 # substituting nitrogen for air.  thermo.py not working with air cas no.
        r_atm_m3_kmol_deg_k = 0.0820575
        air_t_deg_k = 298.15
        p_atm = 1
        mol_rate_air_kmol_hr = p_atm * air_vol_rate_m3_hr / r_atm_m3_kmol_deg_k / air_t_deg_k
        mass_rate_air_kg_hr = mol_rate_air_kmol_hr * mw_air
        mass_rate_air_kg_s = mass_rate_air_kg_hr / 3600
        self.air_data = Source_Input(description = 'air', mass_flow_kg_s=mass_rate_air_kg_s, mass_composition=[1], temp_k=air_t_deg_k, chem_mix=[self.air_cas_no], cheminfo = self.chems.cheminfo)
        self.air_data.populate_flash_results()
    
    def get_vapor_rates(self):

        vapor_rate_kg_s = (1 - self.liquid_fraction_mass) * self.tot_mass_flow_kg_s

        # assuming that the flash is at an equilibrium point, bumping up the vapor temp by a small amount to force energy balance to see as vapor
        vapor_temp_k = self.temp_k + 0.01
        self.vapor_data = Source_Input(description = 'vapor', mass_flow_kg_s = vapor_rate_kg_s, mass_composition=self.vapor_mass_fracts, temp_k = vapor_temp_k, chem_mix = self.chem_mix_no_air, cheminfo = self.chems.cheminfo)
        self.vapor_data.populate_flash_results()

    def merge_streams(self):

        component_rates = {}
        self.combined_output = Source_Input(cheminfo = self.chems.cheminfo)
        self.combined_output.description = 'combined air, vapor, aerosol, etc'
        self.combined_output.chem_mix = self.chem_mix_with_air
        self.combined_output.mass_composition = np.zeros(len(self.combined_output.chem_mix))
        
        si:Source_Input
        for si in self.source_inputs:
            self.combined_output.mass_flow_kg_s += si.mass_flow_kg_s
            for i in range(len(si.chem_mix)):
                component_mass_rate = si.mass_composition[i] * si.mass_flow_kg_s
                if si.chem_mix[i] not in component_rates:
                    component_rates[si.chem_mix[i]] = component_mass_rate
                    continue
                component_rates[si.chem_mix[i]] += component_mass_rate
        
        for i in range(len(self.combined_output.chem_mix)):
            if self.combined_output.mass_flow_kg_s > 0:
                self.combined_output.mass_composition[i] = component_rates[self.combined_output.chem_mix[i]] / self.combined_output.mass_flow_kg_s
        
        self.combined_output.mass_composition = self.combined_output.mass_composition.tolist()

        self.combined_output.concatenate_component_data_for_mixed_stream(source_inputs=self.source_inputs)

    def energy_balance(self):
        
        e_bal = Energy_Balance(si=self.combined_output, log_handler=self.mi.LOG_HANDLER)
        e_bal.set_temp_where_combined_enthalpy_is_zero()
        self.combined_output = e_bal.si
        
    
    def energy_balance_cat_failure(self):

        # get balanced temperature for catastrophic vessel failure (mixes vapor / aerosol / air in building)
        e_bal = Energy_Balance(si=self.combined_output, log_handler=self.mi.LOG_HANDLER)
        e_bal.set_temp_where_combined_enthalpy_is_zero()
        self.combined_output = e_bal.si
        self.combined_output.populate_flash_results()

        chem_mix = self.combined_output.chem_mix
        mass_comp_np = np.array(self.combined_output.mass_composition)
        mws = self.combined_output.mws
        mol_fracts = helpers.mol_fracts_from_mass_fracts(masses=mass_comp_np, mws=mws)
        mass_in_bldg_kg = self.combined_output.mass_flow_kg_s
        component_masses_in_bldg_kg_np = mass_in_bldg_kg * mass_comp_np
        
        prev_source_input = self.combined_output

        # step across dynamic data inputs
        pool_dyn_data:pd.DataFrame = self.pool_evap_data.dynamic_df

        chem_mix = self.pool_evap_data.chem_mix
        mass_comp_np = np.array(self.pool_evap_data.mass_composition)
        mws = self.pool_evap_data.mws
        mass_to_pool_kg = self.data_for_catastrophic_release_model['mass_to_pool_kg']
        component_masses_in_pool_kg_np = mass_to_pool_kg * mass_comp_np
        
            
        t_prev = 0
        t0 = d_time.now(datetime.UTC)
        t00 = t0
        iter = 1
        keep_looping = True
        total_released_masses_np = None
        mol_fracts_over_time = []
        while keep_looping:
            curr_step_pool_evap_src_input = Source_Input(chem_mix=chem_mix, mass_composition = [1] * len(chem_mix), cheminfo=self.chems.cheminfo)
            curr_step_pool_evap_src_input.populate_flash_results()
            dt = 10 # seconds. default time step
            pool_evap_masses_kg_np = np.zeros(len(chem_mix))
            t_curr = t_prev + dt
            if iter < len(pool_dyn_data):
                curr_pool_step_data = self.get_current_pool_evap_src_input_and_t_curr(iter, pool_dyn_data, component_masses_in_pool_kg_np, t_prev=t_prev)
                si_from_method = curr_pool_step_data['curr_pool_evap_si']
                if si_from_method is not None:
                    curr_step_pool_evap_src_input = si_from_method
                t_curr = curr_pool_step_data['t_curr']
                dt = curr_pool_step_data['dt']
                pool_evap_masses_kg_np = curr_pool_step_data['pool_evap_masses_kg_np']

            # 'curr_pool_evap_si': curr_step_pool_evap_src_input,
            # 'component_masses_in_pool_kg_np': component_masses_in_pool_kg_np,
            # 't_curr': t,
            # 'dt': dt
            # 'pool_evap_masses_kg_np'

            curr_step_air_src_input = copy.deepcopy(self.air_data)
            curr_step_air_src_input.mass_flow_kg_s = self.air_data.mass_flow_kg_s * dt
            source_inputs_to_balance = [prev_source_input, curr_step_pool_evap_src_input, curr_step_air_src_input]
            prev_source_input.concatenate_component_data_for_mixed_stream(source_inputs_to_balance)
            prev_temp_k = prev_source_input.temp_k
            e_bal = Energy_Balance(si=prev_source_input, log_handler=self.mi.LOG_HANDLER)
            e_bal.set_temp_where_combined_enthalpy_is_zero(prev_temp_k = prev_temp_k)
            prev_source_input = e_bal.si
            prev_source_input.populate_flash_results()
            component_masses_in_pool_kg_np -= pool_evap_masses_kg_np

            air_flow_kg_s = self.air_data.mass_flow_kg_s
            mass_comp_exiting_np = np.array(prev_source_input.mass_composition)
            component_exit_masses_kg_np = air_flow_kg_s * mass_comp_exiting_np

            if total_released_masses_np is None:
                total_released_masses_np = np.zeros(len(prev_source_input.chem_mix))
            
            total_released_masses_np += component_exit_masses_kg_np

            keep_looping = False
            
            # add to the building component masses from each of the components in the releasing stream
            # subtract the portion of component discharged via the airflow

            for i in range(len(component_masses_in_bldg_kg_np)):
                # either the mass from the pool evaporation will be added
                # or the air flow into the building
                if i < len(pool_evap_masses_kg_np):
                    component_masses_in_bldg_kg_np[i] += pool_evap_masses_kg_np[i]
                else:
                    component_masses_in_bldg_kg_np[i] += curr_step_air_src_input.mass_flow_kg_s
                component_masses_in_bldg_kg_np[i] -= component_exit_masses_kg_np[i]
                component_masses_in_bldg_kg_np[i] = max(component_masses_in_bldg_kg_np[i], 0)

                if i < len(pool_evap_masses_kg_np):
                # if any non-air component mass is still greater than zero, keep on performing the analysis
                    if component_masses_in_bldg_kg_np[i] > 0:
                        keep_looping = True
            
            # adjust the modeled building to represent current component masses
                        
            mass_fracts_in_bldg = helpers.normalize_fractions(component_masses_in_bldg_kg_np.tolist())
            prev_source_input.mass_flow_kg_s = component_masses_in_bldg_kg_np.sum()
            prev_source_input.mass_composition = mass_fracts_in_bldg
            prev_source_input.populate_flash_results()

            mol_fracts_in_bldg = prev_source_input.molfs

            out_data = {prev_source_input.chem_mix[i]:mol_fracts_in_bldg[i] for i in range(len(mol_fracts_in_bldg))}
            out_data['time_s'] = t_curr
            out_data['mass_flow_kg_s'] = air_flow_kg_s

            mol_fracts_over_time.append(out_data)

            t1 = d_time.now(datetime.UTC)
            t1_0 = t1-t0
            t1_00 = t1 - t00
            t0 = t1
            print(f'\n-------\n\niter: {iter}.  dt_step: {t1_0}.  time_overall:  {t1_00}.  temp k: {prev_source_input.temp_k}.  masses_evapd: {pool_evap_masses_kg_np}.  masses remaining: {component_masses_in_bldg_kg_np}. building_release_time: {t_curr}.  temp: {prev_source_input.temp_k}\n---------\n\n')

            if t_curr > 3600:
                break
            t_prev = t_curr
            iter += 1

        cols = ['time_s', 'mass_flow_kg_s']
        cols.extend(prev_source_input.chem_mix)
        mol_fracts_over_time_df = pd.DataFrame(mol_fracts_over_time, columns = cols)

        mass_composition = helpers.normalize_fractions(total_released_masses_np.tolist())
        
        targ_idx = self.get_worst_case_time_steps_for_all_hazard_types(mol_fracts_over_time_df)

        if targ_idx is not None:
            targ_row = mol_fracts_over_time_df.iloc[targ_idx].values
            mol_fracts = targ_row[2:]
            mass_composition = helpers.mass_fracts_from_mol_fracts(mol_fracts.tolist(), mws=prev_source_input.mws)
        
        temp_k = prev_source_input.temp_k
        press_pa = prev_source_input.press_pa
        chem_mix = prev_source_input.chem_mix
        mass_flow_kg_s = self.air_data.mass_flow_kg_s

        self.combined_output = Source_Input(description='combined output', mass_flow_kg_s = mass_flow_kg_s, mass_composition=mass_composition, temp_k = temp_k, press_pa = press_pa, chem_mix = chem_mix, cheminfo = self.chems.cheminfo)
        self.combined_output.populate_flash_results()

        self.mol_fracts_and_mass_rate_by_time_df = mol_fracts_over_time_df

    
    def get_current_pool_evap_src_input_and_t_curr(self, i, pool_dyn_data, component_masses_in_pool_kg_np, t_prev):
        chem_mix = self.pool_evap_data.chem_mix
        mass_comp_np = np.array(self.pool_evap_data.mass_composition)
        mws = self.pool_evap_data.mws
        mol_fracts = helpers.mol_fracts_from_mass_fracts(masses=mass_comp_np, mws=mws)
        row = pool_dyn_data.iloc[i]
        t = row['time_sec']
        dt = t - t_prev
        v_dot = row['vap_rate_kg_per_sec']
        if v_dot == 0 or dt == 0:
            return {
                'curr_pool_evap_si': None,
                't_curr': t,
                'dt': dt,
                'pool_evap_masses_kg_np': np.zeros(len(self.pool_evap_data.chem_mix)),
            }
        v = v_dot * dt
        rel_mass = v
        # l_dot = row['liq_rate_kg_per_sec']
        # l = l_dot * dt
        # rel_mass += l
        temp_k = row['temp_k']
        flash_data = thermo_pio.ideal_flash_calc_get_vf_xs_ys_mol_basis(chem_mix=chem_mix, mws=mws, overall_molfs=mol_fracts, temp_K=temp_k, press_Pa=self.press_pa, cheminfo=self.chems.cheminfo)
        pool_evap_ys = flash_data['ys']
        press_pa = 101325
        if sum(pool_evap_ys) == 0:
            # data = thermo_pio.get_dew_point_press_pa_return_press_pa_and_flash_data(py_lopa_flash_data=flash_data, cheminfo = self.chems.cheminfo, mat = self.pws_material_for_dew_point_pressure_calc)
            # flash_data = data['flash_data']
            # press_pa = flash_data['press_pa']
            pool_evap_ys = np.array(flash_data['k_times_zi'])
            if pool_evap_ys.sum() > 0:
                pool_evap_ys /= pool_evap_ys.sum()
            # self.pws_material_for_dew_point_pressure_calc = data['pws_material']

        pool_evap_mass_fracts = helpers.mass_fracts_from_mol_fracts(molfs=pool_evap_ys, mws=mws)
        pool_evap_mass_fracts_np = np.array(pool_evap_mass_fracts)
        
        pool_evap_masses_kg_np = rel_mass * pool_evap_mass_fracts_np

        # don't evaporate more of a species than exists in the liquid pool
        for i in range(len(pool_evap_masses_kg_np)):
            pool_evap_masses_kg_np[i] = min(pool_evap_masses_kg_np[i], component_masses_in_pool_kg_np[i])
        
        # get build enthalpy table for pool evap source term
        curr_step_pool_evap_src_input = Source_Input(description='current step of dynamic pool evaporation', 
                                                        mass_flow_kg_s=rel_mass, 
                                                        mass_composition=pool_evap_masses_kg_np,
                                                        temp_k = temp_k, 
                                                        press_pa = press_pa,
                                                        chem_mix = chem_mix,
                                                        cheminfo=self.chems.cheminfo)
        
        curr_step_pool_evap_src_input.populate_flash_results(flash_calc=flash_data)

        return {
            'curr_pool_evap_si': curr_step_pool_evap_src_input,
            't_curr': t,
            'dt': dt,
            'pool_evap_masses_kg_np': pool_evap_masses_kg_np,
        }

    def get_worst_case_time_steps_for_all_hazard_types(self, mol_fracts_over_time_df:pd.DataFrame):

        row = mol_fracts_over_time_df.iloc[0]
        mixture_cas_nos = list(row.index)
        mixture_cas_nos = mixture_cas_nos[2:]

        lels = {cas_no: helpers.get_lel(cas_no, cheminfo=self.chems.cheminfo) for cas_no in mixture_cas_nos}
        locs = {cas_no:helpers.get_tox_limits(cas_no, cheminfo=self.chems.cheminfo) for cas_no in mixture_cas_nos}

        lims_arr = []
        for _, row in mol_fracts_over_time_df.iterrows():
            lims = self.find_conc_limits_of_concern(row, lels, locs, mixture_cas_nos)
            lims_arr.append(lims)

        lims_df = pd.DataFrame(lims_arr)
        
        mol_fracts_over_time_df = pd.concat([mol_fracts_over_time_df, lims_df], axis=1)
        # check for location of max inhal and flam
        worst_inhal_idx = None
        nulls = mol_fracts_over_time_df[cd.HAZARD_TYPE_INHALATION].isnull().values.tolist()
        if not all(nulls):
            worst_inhal_idx = mol_fracts_over_time_df[cd.HAZARD_TYPE_INHALATION].idxmin()

        worst_flam_idx = None
        nulls = mol_fracts_over_time_df[cd.HAZARD_TYPE_FLASH_FIRE].isnull().values.tolist()
        if not all(nulls):
            worst_flam_idx = mol_fracts_over_time_df[cd.HAZARD_TYPE_FLASH_FIRE].idxmin()
        
        targ_idx = None
        if worst_flam_idx is None:
            targ_idx = worst_inhal_idx
        
        if worst_inhal_idx is None:
            targ_idx = worst_flam_idx
        
        if worst_flam_idx is not None and worst_inhal_idx is not None:
            worst_inhal = mol_fracts_over_time_df[cd.HAZARD_TYPE_INHALATION].min()
            worst_flam = mol_fracts_over_time_df[cd.HAZARD_TYPE_FLASH_FIRE].min()
            if worst_flam < worst_inhal:
                targ_idx = worst_flam_idx
            else:
                targ_idx = worst_inhal_idx

        return targ_idx
    
    def find_conc_limits_of_concern(self, row:pd.Series, lels, locs, mixture_cas_nos):

        mi = self.mi

        worst_shi = -1
        worst_shi_idx = -1
        targ_loc = 0
        lel_contribs = 0

        for c in mixture_cas_nos:
            molf = row[c]
            if mi.INHALATION:
                locs_for_cas = locs[c]
                loc3 = locs_for_cas[-1]
                shi = -1
                if not pd.isna(loc3) and loc3 < 1e6:
                    shi = molf / loc3
                if shi > worst_shi and molf > 0:
                    worst_shi = shi
                    # the target concentration will be worst-case toxic conc, but corrected 
                    # for its overall concentration in the vapor phase. 
                    # that is, if chemical X is lethal at 100 ppm 
                    # and the vapor phase is 10% chemical X, then the 
                    # concentration of the vapor phase is toxic at 100 ppm / 10% = 1000 ppm

                    targ_loc = loc3 / molf
            
            if mi.FLASH_FIRE:
                #determine average lel of vapor phase based on le chatlier's mixing rule
                lel = 1000000000000 #large value to negate contribution of non-flammable to average LFL
                lel_val = lels[c]
                if not pd.isna(lel_val):
                    if lel_val > 0 and lel_val < 1e6:
                        lel = lel_val
                lel_contribs += molf / lel

        goverining_inhal_conc = None
        if mi.INHALATION:

            if targ_loc > 0 and targ_loc < 1e6:
                goverining_inhal_conc = targ_loc
        
        flam_loc = None
        if mi.FLASH_FIRE:
            
            # ave LFL = 1/lel_contribs.  If lel_contribs is less than 1e-6,
            # then the LFL > 1,000,000 ppm, which is not credible.

            if lel_contribs > 1e-6:
                flam_loc = 1 / lel_contribs
        
        return {
            cd.HAZARD_TYPE_FLASH_FIRE: flam_loc,
            cd.HAZARD_TYPE_INHALATION: goverining_inhal_conc
        }
    


    def update_input_parameters(self):

        # update chems to include air
        self.inputs['chemical_mix'] = self.combined_output.chem_mix

        # composition is made of the mass-based evaporations, aerosol, vapor and airflow contributions 
        self.inputs['composition'] = self.combined_output.mass_composition
        self.inputs['comp_is_moles'] = False
        self.inputs['relief_phase'] = cd.PHASE_LET_MODEL_DECIDE
        self.inputs['relief_calc_available'] = True
        tot_rate_kg_s = self.combined_output.mass_flow_kg_s
        tot_rate_lb_hr = tot_rate_kg_s * Consts.LB_PER_KG * 3600
        self.inputs['relief_calc_rate_lb_hr'] = tot_rate_lb_hr
        self.inputs['max_hole_size_in'] = self.inputs['room_vent_diameter_in']
        self.inputs['temp_deg_c'] = self.combined_output.temp_k - 273.15
        self.inputs['pressure_psig'] = p_targ_psig # utilizing a small delta P such that the vent diameter does not deviate much when iterating to match rate.
        self.inputs['release_elevation_m'] = self.inputs['room_vent_elevation_m']
        self.inputs['catastrophic_vessel_failure'] = False
        self.inputs['storage_mass_kg'] = tot_rate_kg_s * 3600 # set max qty to study to equal an hour at max rate
        self.inputs['storage_volume_m3'] = None
        self.inputs['release_angle_degrees_from_horizontal'] = self.inputs['room_vent_release_angle_degrees_from_horizontal']
        self.inputs['release_indoors'] = False # exfiltrating from indoors to outdoors, so no longer need to do any further analysis of indoor modeling dynamics
        self.inputs['available_pool_area_m2'] = None
    
    def launch_model_controller(self):
        self.mc = Model_Controller(inputs=self.inputs, release_durations_to_model_sec=self.release_durations_to_model_sec)
        self.resultCode = self.mc.run()

        log_handler = self.mi.LOG_HANDLER
        self.data = self.mc.data 

        if self.resultCode == ResultCode.SUCCESS:
            self.mi.LOG_HANDLER('Exfiltration model for this time step completed successfully')
        elif self.resultCode == ResultCode.NO_DISCHARGE_RECORDS_ERROR:
            log_handler(f'no discharge or dispersion emissions from the exfiltration model in this time step')
        else:
            log_handler(f'an unexpected error has occurred with the exfiltration model in this time step.')
                

        

from py_lopa.model_work.model_controller import Model_Controller 