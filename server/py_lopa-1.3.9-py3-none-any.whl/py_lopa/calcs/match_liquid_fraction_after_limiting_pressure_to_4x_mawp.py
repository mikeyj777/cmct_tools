from pypws.entities import Phase, FlashResult

from py_lopa.calcs.consts import Consts
from py_lopa.phast_io import phast_prep
from py_lopa.data.exception_enum import Exception_Enum


def drop_temp_to_match_liquid_fraction_if_pressure_dropped_to_below_4x_mawp(mi, state, flashresult:FlashResult, material):

    if flashresult.fluid_phase == Phase.LIQUID or mi.RELIEF_PHASE == Consts().RELIEF_PHASE.LIQUID:
        return mi.TEMP_K

    
    if mi.PRESS_PA <= 4 * (mi.MAWP_PA - 101325) + 101325:
        return mi.TEMP_K
    mi.LOG_HANDLER('Pressure entered is greater than 4xMAWP.  In systems with vapor, it is likely that vessels will fail when at 4xMAWP.')
    mi.LOG_HANDLER('Pressure in the model will be limited to 4xMAWP.  If necessary, temperature will be adjusted to match the liquid level of the system.')

    # using a small value so that the pct difference bet target and current liquid fractions is possible.
    liq_mass_frac_targ = max(flashresult.liquid_mass_fraction, 1e-16)

    mi.PRESS_PA = min(mi.PRESS_PA, 4 * (mi.MAWP_PA - 101325) + 101325)
    state = phast_prep.prep_state(
        press_pa=mi.PRESS_PA, 
        temp_K=mi.TEMP_K, 
        use_multicomponent_modeling=mi.USE_MULTICOMPONENT_METHOD
    )
    flashresult = phast_prep.flash_calc(state, material, mi=mi)
    
    # if curr_phase == new_phase:
    #     return mi.TEMP_K

    new_liq_mass_frac = max(flashresult.liquid_mass_fraction, 1e-16)
    if abs(new_liq_mass_frac - liq_mass_frac_targ) / liq_mass_frac_targ <= 0.05:
        return mi.TEMP_K
    
    temp_k = mi.TEMP_K
    args = {
        'press_pa': mi.PRESS_PA,
        'mi': mi,
        'material': material,
        'initial_liq_mass_frac': new_liq_mass_frac,
        'target_liq_mass_frac': liq_mass_frac_targ,
    }
    
    temp_range_dict = decrease_temp_exponentially_until_phase_changes_return_temp_range_dict_for_bisection(temp_k=mi.TEMP_K, args=args)
    temp_k = get_highest_temp_matching_liquid_mass_fraction_within_tolerance(temp_range_dict=temp_range_dict, args=args)
        
    return temp_k

def decrease_temp_exponentially_until_phase_changes_return_temp_range_dict_for_bisection(temp_k, args):

    liq_mass_fract_target = args['target_liq_mass_frac']
    lmf = args['initial_liq_mass_frac']
    # lowering temp the model returns an error.  then finding the minimum valid point as the lower bound for the analysis.
    # 10 K is the lowest allowable temp for modeling in pws, so setting that as absolute bottom

    t_high = temp_k
    t_low = temp_k
    while lmf is not None and t_low > 10 and lmf < 0.995 * liq_mass_fract_target:
        t_low = t_high / 1.1
        if t_low < 10:
            break
        lmf = get_liquid_mass_fraction(temp_k=t_low, args=args)
        t_high = t_low
    t_low = max(t_low, 10)
    if lmf is None:
        t_low = find_lowest_valid_temp(t_low=t_low, t_high=t_low * 1.1, args=args)
    
    t_high = t_low * 1.1

    return {
        'temp_low_k': t_low,
        'temp_high_k': t_high,
    }
        
def find_lowest_valid_temp(t_low, t_high, args):

    # finding the lowest range which will report results.  delta is the difference between failed temp and working temp.
    mi = args['mi']
    delta = t_high - t_low
    temp_k = (t_high + t_low) / 2
    max_iters = 60
    iter = 0
    while delta > 0.1 and iter < max_iters:
        iter += 1
        lmf = get_liquid_mass_fraction(temp_k=temp_k, args=args)
        if lmf is None:
            t_low = temp_k
        else:
            t_high = temp_k
        delta = t_high - t_low
        temp_k = (t_high + t_low) / 2
    if iter >= max_iters:
        mi.LOG_HANDLER('Could not successfully match the liquid fraction from the source.  Using originally entered Temperature.')
        return t_high
    return t_low

def get_highest_temp_matching_liquid_mass_fraction_within_tolerance(temp_range_dict, args):
    t_low_k = temp_range_dict['temp_low_k']
    t_high_k = temp_range_dict['temp_high_k']
    liq_mass_fract_target = args['target_liq_mass_frac']
    mi = args['mi']
    lmf = -1
    temp_k = t_high_k
    while temp_k >= t_low_k and lmf < 0.995 * liq_mass_fract_target and lmf is not None:
        temp_k -= 1
        lmf = get_liquid_mass_fraction(temp_k=temp_k, args=args)
    if lmf is None:
        mi.LOG_HANDLER('Could not successfully match the liquid fraction from the source.  Using originally entered Temperature.')
        return t_high_k
    return temp_k


def get_liquid_mass_fraction(temp_k, args):
    press_pa = args['press_pa']
    mi = args['mi']
    material = args['material']
    use_multicomponent_modeling = mi.USE_MULTICOMPONENT_METHOD
    lmf = None
    try:
        state = phast_prep.prep_state(
            press_pa=press_pa, 
            temp_K=temp_k, 
            use_multicomponent_modeling=use_multicomponent_modeling
        )
        flashresult = phast_prep.flash_calc(state, material, mi=mi)
        lmf = flashresult.liquid_mass_fraction
    except:
        pass

    return lmf