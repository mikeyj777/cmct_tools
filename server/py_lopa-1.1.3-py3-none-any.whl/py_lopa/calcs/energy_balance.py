import copy
import numpy as np
import pandas as pd
import datetime
from datetime import datetime as dt


from py_lopa.classes.source_input import Source_Input
from py_lopa.classes.phys_props import Phys_Props
from py_lopa.calcs import helpers, thermo_pio, dippr_eqns
from py_lopa.data.exception_enum import Exception_Enum
from py_lopa.data.tables import Tables
from py_lopa.calcs.consts import Consts
from py_lopa.classes.solver import Solver

cd = Consts().CONSEQUENCE_DATA

# integCp is the anti-derivative of the heat capacity calculated value, based on the appropriate dipper equation.
# specific enthalpy is calculated by subtracting integCp at final temp by integCp at starting temp
# temp - deg K.  integCp - J/kmol

# hvap is heat of vaporization - difference in enthalpy between mol vapor and mol liquid at temp
# temp - deg K.  hvap - J/kmol

class Energy_Balance:

    def __init__(self, si:Source_Input, target_pressure_pa = 101325, log_handler=print):
        self.si = si
        self.log_handler = log_handler
        self.press_pa = target_pressure_pa
        self.cheminfo = si.cheminfo
        self.e_bal_iter = 0
        self.params = {
            'chem_mix': [],
            'mws': [],
            'molfs': [],
            'total_molar_flow_kmol_s': None,
        }

    def run():
        pass
    
    def update_component_data_with_cps_hvap_and_optional_final_moles(self, get_final_moles = True, temp_k = None):
        
        # translate between 'get initial cps' boolean and appropriate state to document cps
        state_dict = {
            False: 'start',
            True: 'final'
        }

        comp_data_updated = []
        for comp_data in self.si.component_data_df.to_dict(orient='records'):
            cas_no = comp_data['cas_no']
            if cas_no not in self.si.phys_props_dict.keys():
                self.si.phys_props_dict[cas_no] = Phys_Props(cas_no=cas_no)
            self.si.phys_props_dict[cas_no].get_property_values_and_constants(temp_k)
            pp:Phys_Props
            pp = self.si.phys_props_dict[cas_no]
            tc = pp.tc
            if not get_final_moles:
                temp_k = comp_data['temp_k']
                
            x_integ_cp = 0
            if temp_k <= tc:
                x_integ_cp = self.integrated_cp_calc(pp=pp, temp_k=temp_k, phase = cd.PHASE_LIQUID)

            y_integ_cp = self.integrated_cp_calc(pp=pp, temp_k=temp_k, phase = cd.PHASE_VAPOR)
            state = state_dict[get_final_moles]
            comp_data['x_integ_cp_' + state] = x_integ_cp
            comp_data['y_integ_cp_' + state] = y_integ_cp
            comp_data_updated.append(comp_data)
        
        self.si.component_data_df = pd.DataFrame(comp_data_updated)

        if not get_final_moles:

            return 
        
        chem_mix = self.params['chem_mix']
        mws = self.params['mws']
        molfs = self.params['molfs']
        total_molar_flow_kmol_s = self.params['total_molar_flow_kmol_s']
        if len(chem_mix) == 0:
            chem_mix = self.si.component_data_df['cas_no'].to_list()
            mws = [helpers.get_mw(x, cheminfo=self.cheminfo) for x in chem_mix]
            molar_flows_kmol_s_np = self.si.component_data_df['tot_moles_x_and_y'].to_numpy()
            total_molar_flow_kmol_s = molar_flows_kmol_s_np.sum()
            molfs = molar_flows_kmol_s_np / total_molar_flow_kmol_s

            self.params['chem_mix'] = chem_mix
            self.params['mws'] = mws
            self.params['molfs'] = molfs
            self.params['total_molar_flow_kmol_s'] = total_molar_flow_kmol_s

        flash_calc = thermo_pio.ideal_flash_calc_get_vf_xs_ys_mol_basis(chem_mix=chem_mix, mws = mws, overall_molfs=molfs, temp_K=temp_k, press_Pa=self.press_pa, cheminfo=self.cheminfo)

        xs = flash_calc['xs']
        ys = flash_calc['ys']
        overall_vap_molf = flash_calc['vf']

        x_moles = total_molar_flow_kmol_s * np.array(xs) * (1 - overall_vap_molf)
        y_moles = total_molar_flow_kmol_s * np.array(ys) * overall_vap_molf
        
        self.si.component_data_df['x_moles_final'] = x_moles
        self.si.component_data_df['y_moles_final'] = y_moles

    
    def get_enthalpy_changes_from_starting_temps_to_temp_2(self, temp_2):
        
        # component_data.append({
        #     'source_description': self.description,
        #     'cas_no': self.chem_mix[i],
        #     'temp_k': self.temp_k,
        #     'press_pa': self.press_pa,
        #     'x_moles_start': x_moles_i,
        #     'y_moles_start': y_moles_i,
        #     'tot_moles_x_and_y': x_moles_i + y_moles_i,
        #     'x_integ_cp_start': None,
        #     'y_integ_cp_start': None,
        #     'x_moles_final': None,
        #     'y_moles_final': None,
        #     'x_integ_cp_final': None,
        #     'y_integ_cp_final': None,
        #     'heat_of_vaporization_j_kmol': None,
        #     'heat_of_vaporization_j': None,
        #     'sensible_heat_j': None,
        #     'total_enthalpy_change_j': None
        # })

        x_integ_cps_start = self.si.component_data_df['x_integ_cp_start'].tolist()
        
        if None in x_integ_cps_start:
            self.update_component_data_with_cps_hvap_and_optional_final_moles(get_final_moles=False)
            
        self.update_component_data_with_cps_hvap_and_optional_final_moles(get_final_moles=True, temp_k=temp_2)

        y_mol_fin_np = self.si.component_data_df['y_moles_final'].to_numpy()
        y_mol_start_np = self.si.component_data_df['y_moles_start'].to_numpy()

        delta_y_moles_np = y_mol_fin_np - y_mol_start_np

        self.set_heats_of_vaporization_j_kmol(temp_k=temp_2)

        h_vaps_j_kmol_np = self.si.component_data_df['heat_of_vaporization_j_kmol'].to_numpy()
        
        self.si.component_data_df['heat_of_vaporization_j'] = delta_y_moles_np * h_vaps_j_kmol_np
        h_vap_j = self.si.component_data_df['heat_of_vaporization_j'].sum()
        
        x_mol_fin_np = self.si.component_data_df['x_moles_final'].to_numpy()
        x_integ_cp_fin_np = self.si.component_data_df['x_integ_cp_final'].to_numpy()
        x_integ_cp_start_np = self.si.component_data_df['x_integ_cp_start'].to_numpy()

        y_integ_cp_fin_np = self.si.component_data_df['y_integ_cp_final'].to_numpy()
        y_integ_cp_start_np = self.si.component_data_df['y_integ_cp_start'].to_numpy()


        self.si.component_data_df['sensible_heat_j'] = x_mol_fin_np * (x_integ_cp_fin_np - x_integ_cp_start_np)
        self.si.component_data_df['sensible_heat_j'] += y_mol_fin_np * (y_integ_cp_fin_np - y_integ_cp_start_np)

        self.si.component_data_df['total_enthalpy_change_j'] = self.si.component_data_df['heat_of_vaporization_j'] + self.si.component_data_df['sensible_heat_j']

        tot_h = self.si.component_data_df['total_enthalpy_change_j'].sum()

        return tot_h
                
    def integrated_cp_calc(self, pp:Phys_Props, temp_k, phase=cd.PHASE_VAPOR):

        tc = pp.tc
        
        prop_id = 'icp'
        if phase == cd.PHASE_LIQUID:
            prop_id = 'lcp'
        
        cp_data = pp.get_closest_property_dataset_to_temp(prop_id=prop_id, temp_k=temp_k)        
        cp_consts = cp_data['coefficients']
        eqn_id = cp_data['eqn_id']

        dippr_fxn = getattr(dippr_eqns, 'eqn_' + str(eqn_id))

        integ_cp = dippr_fxn(consts=cp_consts, t=temp_k, tc=tc, integrated=True)
        
        return integ_cp

    def set_heats_of_vaporization_j_kmol(self, temp_k):
        
        chem_mix = self.params['chem_mix']

        if len(chem_mix) == 0:
            chem_mix = self.si.component_data_df['cas_no'].to_list()
            self.params['chem_mix'] = chem_mix
        
        h_vaps_j_kmol = []
        for cas_no in chem_mix:
            pp:Phys_Props = self.si.phys_props_dict[cas_no]
            tc = pp.tc
            h_vap_j_kmol = 0
            if temp_k < tc:
                h_vap_j_kmol = self.get_heat_of_vaporization_j_kmol(pp=pp, temp_k=temp_k)
            h_vaps_j_kmol.append(h_vap_j_kmol)
        
        self.si.component_data_df['heat_of_vaporization_j_kmol'] = h_vaps_j_kmol

    def get_heat_of_vaporization_j_kmol(self, pp:Phys_Props, temp_k):

        hvap_data = pp.get_closest_property_dataset_to_temp(prop_id='hvp', temp_k=temp_k)

        hvap_consts = hvap_data['coefficients']
        eqn_id = hvap_data['eqn_id']
        tc = pp.tc

        dippr_fxn = getattr(dippr_eqns, 'eqn_' + str(eqn_id))

        hvap = dippr_fxn(consts=hvap_consts, t=temp_k, tc = tc)

        return hvap
    

    
    def set_temp_where_combined_enthalpy_is_zero(self, debug = False):

        # use starting temp as initial temperature guess
        t_guess = 298.15

        args = {
            'debug': debug
        }

        solver = Solver(args = args, arg_to_vary=t_guess, fxn_to_solve=self.enthalpy_over_all_streams, ytol=1)
        solver.set_bisect_parameters(lower_limit=100, upper_limit=3000, output_increases_as_input_increases=True)
        
        solver_ok = solver.solve()

        if solver_ok:
            self.si.temp_k = solver.answer
            return

        self.log_handler('\n\n\nenergy balance is out of spec.  solution may be in error\n\n\n')

        self.si.temp_k = solver.current_guess
        
        
        

    def enthalpy_over_all_streams(self, x0, args = {}):

        temp_k = x0

        debug = False
        if 'debug' in args:
            debug = args['debug']

        tot_h = self.get_enthalpy_changes_from_starting_temps_to_temp_2(temp_2 = temp_k)

        if debug:
            time_stamp = helpers.time_stamp_format(dt.now(datetime.UTC))
            temp_k = str(temp_k)
            temp_k = temp_k.replace('.', '_')
            self.si.component_data_df.to_csv(f'e_bal_debug/_iter_{self.e_bal_iter}_time_{time_stamp}_utc_component_data_temp_{temp_k}_k.csv')
            self.e_bal_iter += 1
        
        self.t_final_deg_k = temp_k
        
        return tot_h






