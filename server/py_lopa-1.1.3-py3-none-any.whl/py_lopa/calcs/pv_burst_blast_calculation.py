import math
import copy
import pandas as pd
import numpy as np
from scipy.interpolate import interp2d


from pypws.calculations import VesselLeakCalculation

from py_lopa.data.tables import Tables
from py_lopa.data.exception_enum import Exception_Enum
from py_lopa.calcs import helpers




class Pv_Burst_Blast_Calc:

    def __init__(self, phast_discharge) -> None:
        self.pv_burst_curves_df = helpers.get_dataframe_from_csv(Tables().PV_BURST_BLAST_CURVE_DATA)
        self.phast_discharge = phast_discharge
        self.mi = phast_discharge.mi
        self.vlc:VesselLeakCalculation = phast_discharge.vesselLeakCalculation
        self.press_pa = self.mi.PRESS_PA
        self.flash_at_init = self.phast_discharge.flashresult
        self.expansion_energy_j = self.vlc.discharge_result.expansion_energy * self.vlc.discharge_result.release_mass
        self.bldgs = self.mi.bldgs
        self.p_ratio = self.get_p_ratio()
    
    def run(self):

        for bldg in self.bldgs:
            dist_m = bldg.dist_m
            scaled_r = self.get_scaled_r(dist_m=dist_m)
            bldg.pv_burst_overpressure_psi = self.get_overpressure_psi_at_bldg(scaled_r=scaled_r)

            
    def get_p_ratio(self):
        p_ratio = self.press_pa / 101325
        max_p_ratio = self.pv_burst_curves_df['p1_p0'].max()
        min_p_ratio = self.pv_burst_curves_df['p1_p0'].min()
        p_ratio = min(p_ratio, max_p_ratio)
        p_ratio = max(p_ratio, min_p_ratio)

        return p_ratio

    def get_scaled_r(self, dist_m):
        return dist_m / ( self.expansion_energy_j / 101325 ) ** (1/3)

    def get_overpressure_psi_at_bldg(self, scaled_r):

        p_ratio = self.p_ratio
        df = self.pv_burst_curves_df

        targ_p1_p0 = df[df['p1_p0'] == p_ratio]
        targ_p1_p0_prime = {}
        if len(targ_p1_p0) > 1:
            raise Exception(Exception_Enum.MALFORMED_DATA)
        
        if len(targ_p1_p0) == 1:
            row = targ_p1_p0[targ_p1_p0['scaled_r'] == scaled_r]
            if len(row) != 0:
                overpress_psia = 2 * abs(14.6959 * (1 + helpers.get_data_from_pandas_series_element(row['scaled_press'].max())))
                return overpress_psia

        if len(targ_p1_p0) == 0:
            targ_p1_p0 = df[df['p1_p0'] < p_ratio]
            targ_p1_p0 = targ_p1_p0[targ_p1_p0['p1_p0'] == targ_p1_p0['p1_p0'].max()]
            targ_p1_p0_prime = df[df['p1_p0'] > p_ratio]
            targ_p1_p0_prime = targ_p1_p0_prime[targ_p1_p0_prime['p1_p0'] == targ_p1_p0_prime['p1_p0'].min()]
        
        targ_p1_p0_r_bounds = {}
        if scaled_r > targ_p1_p0['scaled_r'].max():
            targ_p1_p0_r_bounds = targ_p1_p0.tail(2)
        
        if len(targ_p1_p0_r_bounds) == 0:
            targ_p1_p0_lower_r = targ_p1_p0[targ_p1_p0['scaled_r'] < scaled_r]
            targ_p1_p0_lower_r = targ_p1_p0_lower_r[targ_p1_p0_lower_r['scaled_r'] == targ_p1_p0_lower_r['scaled_r'].max()]
            targ_p1_p0_higher_r = targ_p1_p0[targ_p1_p0['scaled_r'] > scaled_r]
            targ_p1_p0_higher_r = targ_p1_p0_higher_r[targ_p1_p0_higher_r['scaled_r'] == targ_p1_p0_higher_r['scaled_r'].min()]
            targ_p1_p0_r_bounds = pd.concat([targ_p1_p0_lower_r, targ_p1_p0_higher_r])

        targ_p1_p0_prime_r_bounds = {}
        if len(targ_p1_p0_prime) > 0 and scaled_r > targ_p1_p0_prime['scaled_r'].max():
            targ_p1_p0_prime_r_bounds = targ_p1_p0_prime.tail(2)

        if len(targ_p1_p0_prime_r_bounds) == 0 and len(targ_p1_p0_prime) > 0:
            targ_p1_p0_prime_lower_r = targ_p1_p0_prime[targ_p1_p0_prime['scaled_r'] < scaled_r]
            targ_p1_p0_prime_lower_r = targ_p1_p0_prime_lower_r[targ_p1_p0_prime_lower_r['scaled_r'] == targ_p1_p0_prime_lower_r['scaled_r'].max()]
            targ_p1_p0_prime_higher_r = targ_p1_p0_prime[targ_p1_p0_prime['scaled_r'] > scaled_r]
            targ_p1_p0_prime_higher_r = targ_p1_p0_prime_higher_r[targ_p1_p0_prime_higher_r['scaled_r'] == targ_p1_p0_prime_higher_r['scaled_r'].min()]
            targ_p1_p0_prime_r_bounds = pd.concat([targ_p1_p0_prime_lower_r, targ_p1_p0_prime_higher_r])
        
        low_p_low_r = targ_p1_p0_r_bounds['scaled_r'].min()
        low_r_scaled_p_row = targ_p1_p0_r_bounds[targ_p1_p0_r_bounds['scaled_r'] == low_p_low_r]
        low_r_scaled_p = helpers.get_data_from_pandas_series_element(low_r_scaled_p_row['scaled_press'])
        low_p_high_r = targ_p1_p0_r_bounds['scaled_r'].max()
        high_r_scaled_p_row = targ_p1_p0_r_bounds[targ_p1_p0_r_bounds['scaled_r'] == low_p_high_r]
        high_r_scaled_p = helpers.get_data_from_pandas_series_element(high_r_scaled_p_row['scaled_press'])
        low_p_ratio_scaled_p = self.log_linear_interpolation(x = scaled_r, x1 = low_p_low_r, x2 = low_p_high_r, y1 = low_r_scaled_p, y2 = high_r_scaled_p)
        scaled_p = low_p_ratio_scaled_p

        high_p_ratio_scaled_p = None
        if len(targ_p1_p0_prime_r_bounds) > 0:
            high_p_low_r = targ_p1_p0_prime_r_bounds['scaled_r'].min()
            low_r_scaled_p_row = targ_p1_p0_prime_r_bounds[targ_p1_p0_prime_r_bounds['scaled_r'] == high_p_low_r]
            low_r_scaled_p = helpers.get_data_from_pandas_series_element(low_r_scaled_p_row['scaled_press'])
            high_p_high_r = targ_p1_p0_prime_r_bounds['scaled_r'].max()
            high_r_scaled_p_row = targ_p1_p0_prime_r_bounds[targ_p1_p0_prime_r_bounds['scaled_r'] == high_p_high_r]
            high_r_scaled_p = helpers.get_data_from_pandas_series_element(high_r_scaled_p_row['scaled_press'])
            high_p_ratio_scaled_p = self.log_linear_interpolation(x = scaled_r, x1 = high_p_low_r, x2 = high_p_high_r, y1 = low_r_scaled_p, y2 = high_r_scaled_p)
        
        if high_p_ratio_scaled_p is not None:
            p_ratio_1 = targ_p1_p0['p1_p0'].min()
            p_ratio_2 = targ_p1_p0_prime['p1_p0'].max()
            scaled_p_1 = low_p_ratio_scaled_p
            scaled_p_2 = high_p_ratio_scaled_p
            scaled_p = self.log_linear_interpolation(x=p_ratio, x1 = p_ratio_1, x2 = p_ratio_2, y1=scaled_p_1, y2=scaled_p_2)
        
        return 2 * (1 + scaled_p) * 14.6959

    def log_linear_interpolation(self, x, x1, x2, y1, y2):
        X1 = math.log10(x1)
        X2 = math.log10(x2)
        Y1 = math.log10(y1)
        Y2 = math.log10(y2)
        Y = max(Y1, Y2)
        X = math.log10(x)
        if X1 != X2:
            M = (Y2 - Y1) / (X2 - X1)
            B = Y2 - M * X2
            Y = M*X + B
        y = 10**Y
        return y