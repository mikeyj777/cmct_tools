import copy
import numpy as np
import pandas as pd

from py_lopa.calcs.consts import Consts

cd = Consts().CONSEQUENCE_DATA

class Bldg_Heights_To_Evaluate:

    # ground leved and the ht of each bldg will always be analyzed
    # the vertical boundary of concern (Consts.ELEVATION_RANGE_FOR_CONC_EVAL_M)
    # determines the max and min heights of the range to evaluate around each point
    # points will be filtered such that none are within Consts.MIN_DIST_BET_ELEVS_M of each other

    max_vert_off = Consts.ELEVATION_RANGE_FOR_CONC_EVAL_M
    min_spacing = Consts.MIN_DIST_BET_ELEVS_M

    def __init__(self, mi):
        self.elevs_m = []
        bldgs = mi.bldgs
        #including ground level for conc-based evaluation of impact to personnel in area
        self.bldg_hts_m = [0]
        for i in range(len(bldgs)):
            if not pd.isna(bldgs[i].ht_m):
                self.bldg_hts_m.append(bldgs[i].ht_m)

    def calc_elevs(self):
        
        b = self.bldg_hts_m
        self.elevs_m.extend(b)
        ht_list = []
        for ht in self.bldg_hts_m:
            a = np.linspace(ht - self.max_vert_off, ht + self.max_vert_off, 5)
            a = [max(0,x) for x in a]
            ht_list.extend(a)

        # test each building height to see if there are heights within 
        # the min tolerance.  heights within the min tolerance will be tagged to be removed.
        # the bldg heights themselves will remain.

        ht_list = np.asarray(ht_list)

        for bldg in b:
            # list comp would be more concise, but less readable
            # ht_list = [np.inf if (abs(x - bldg) > 0 and abs(x - bldg) < self.min_spacing) else x for x in ht_list]
            for i in range(ht_list.shape[0]):
                diff = abs(ht_list[i] - bldg)
                if diff > 0 and diff < self.min_spacing:
                    ht_list[i] = np.inf

        ht_list = ht_list[ht_list < np.inf]
        ht_list = list(set(ht_list))
        ht_list = np.asarray(ht_list)
        ht_list.sort()

        # final sweep to remove missed elevations within tolerance
        for i in range(ht_list.shape[0]-1):
            for j in range(i + 1, ht_list.shape[0]):
                if ht_list[i] < np.inf and ht_list[j] < np.inf:
                    if ht_list[j] not in b and abs(ht_list[j] - ht_list[i]) < self.min_spacing:
                        ht_list[j] = np.inf
        
        ht_list = ht_list[ht_list < np.inf]
        ht_list = list(set(ht_list))

        ht_list.sort()

        self.elevs_m = ht_list

        return ht_list






