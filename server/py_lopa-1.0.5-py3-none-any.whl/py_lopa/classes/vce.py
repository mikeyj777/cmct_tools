import numpy as np

from pypws.calculations import DispersionCalculation, LateExplosionCalculation
from pypws.entities import ExplosionConfinedVolume, DispersionOutputConfig, ExplosionOutputConfig, ExplosionParameters
from pypws.enums import Resolution, SpecialConcentration

from py_lopa.calcs import helpers

class VCE:

    def __init__(self, dispersionCalculation:DispersionCalculation, save_disp_calc_pickle = False) -> None:
        self.dispersionCalculation = dispersionCalculation
        if save_disp_calc_pickle:
            self.save_disp_calc_pickle()

    def save_disp_calc_pickle(self):
        helpers.save_object_as_pickle_return_path_and_file_name(self.dispersionCalculation)

    def get_flammable_mass(self):

        late_exp = LateExplosionCalculation(material = None, scalar_udm_outputs = None, weather = None, dispersion_records = None, dispersion_record_count = None, substrate = None, dispersion_output_config = None, explosion_output_config = None, explosion_parameters = None, explosion_confined_volumes = None, explosion_confined_volume_count = None, dispersion_parameters = None)
        late_exp.material = self.dispersionCalculation.material
        late_exp.scalar_udm_outputs = self.dispersionCalculation.scalar_udm_outputs
        late_exp.weather = self.dispersionCalculation.weather
        late_exp.dispersion_records = self.dispersionCalculation.dispersion_records
        late_exp.dispersion_record_count = len(late_exp.dispersion_records)
        late_exp.substrate = self.dispersionCalculation.substrate
        late_exp.dispersion_output_config = self.get_dispersion_output_config()
        late_exp.dispersion_parameters = self.dispersionCalculation.dispersion_parameters

        late_exp.explosion_output_config = ExplosionOutputConfig()
        late_exp.explosion_parameters = ExplosionParameters()

        late_exp.explosion_confined_volumes = []
        
        confine_vol = ExplosionConfinedVolume()
        confine_vol.confined_strength = 10
        confine_vol.confined_volume = 100

        late_exp.explosion_confined_volumes.append(confine_vol)
        late_exp.explosion_confined_volume_count = len(late_exp.explosion_confined_volumes)
        res = late_exp.run()

        self.late_exp = late_exp
        self.flammable_mass = late_exp.explosion_unif_conf_overpressure_result.exploded_mass


        print(f'flammable mass: {self.flammable_mass}')

        apple = 1

    def get_dispersion_output_config(self):

        dispOutputCfg = DispersionOutputConfig()
        dispOutputCfg.resolution = Resolution.MEDIUM
        dispOutputCfg.downwind_distance = np.inf
        dispOutputCfg.special_concentration = SpecialConcentration.LFL

        return dispOutputCfg


