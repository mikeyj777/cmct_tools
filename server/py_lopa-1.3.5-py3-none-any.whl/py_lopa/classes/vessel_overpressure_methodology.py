import copy
import pandas as pd

from pypws.calculations import FlashResult
from pypws.enums import Phase, ResultCode

from py_lopa.data.exception_enum import Exception_Enum
from py_lopa.calcs.consts import Consts
from py_lopa.calcs import thermo_pio
from py_lopa.calcs.get_phys_props import Get_Phys_Props

cd = Consts().CONSEQUENCE_DATA

class Vessel_Overpressure_Methodology:

    def __init__(self, mi, flashresult:FlashResult, py_lopa_flash = None, mc = None, default_data_list=None) -> None:
        self.mc = mc
        self.mi = mi
        self.default_data_list = default_data_list
        self.mawp_pa = mi.MAWP_PA
        self.pressure_factor = None
        if pd.isna(self.mawp_pa):
            self.mi.LOG_HANDER('WARNING:  Attempted to use Vessel Overpressure Methodology Specifications.  However, MAWP was not provided.  Proceeding with Normal Target Table Evaluation.')
            return
        self.mi_rp = self.mi.RELIEF_PHASE
        self.rp_enum = Consts().RELIEF_PHASE
        self.set_pressure_factor()
        self.flashresult = flashresult
        self.high_pressure_two_phase_evaluation_required = False
        self.model_inputs_for_both_phases = {
            self.rp_enum.VAPOR: None,
            self.rp_enum.LIQUID: None,
        }
        self.py_lopa_flash = py_lopa_flash
        self.mi.LOG_HANDLER('This model will attempt use the Vessel Overpressure Methodology Specification.')
        self.output_data_from_two_phase_model = None
        self.results = []

    def set_pressure_factor(self):

        # pressure factor based on overage in terms of gauge pressure
        mawp_gauge = self.mawp_pa - 101325
        sys_press_gauge = self.mi.PRESS_PA - 101325
        self.pressure_factor = sys_press_gauge / mawp_gauge

    def follow_guidance(self):
        if self.pressure_factor >= 1 and self.pressure_factor < 1.3:
            self.pressure_factor_1_to_1_3_x_MAWP()
        if self.pressure_factor >= 1.3 and self.pressure_factor < 2:
            self.pressure_factor_1_3_to_2_x_MAWP()
        if self.pressure_factor >= 2:
            self.pressure_factor_at_least_2_x_MAWP()

    def pressure_factor_1_to_1_3_x_MAWP(self):
        self.mi.LOG_HANDLER('Pressure < 1.3xMAWP.')
        self.mi.LOG_HANDLER('Vessel Overpressure Methodology specifies a release model based on relief evaluation.')
        if self.mi.CATASTROPHIC_VESSEL_FAILURE:
            self.mi.LOG_HANDLER('WARNING:  The Vessel Overpressure Methodology calls for leak-based evaluation in this Pressure Range.  However, Catastrophic Rupture was selected.')
            if self.mi.RELIEF_CALC_AVAILABLE and not pd.isna(self.mi.RELIEF_CALC_RATE_KG_S):
                self.mi.LOG_HANDLER('The Relief rate was entered, so that will be used in this model to match the Vessel Overpressure Methodology.  Catastrophic Rupture will not be used.')
                self.mi.CATASTROPHIC_VESSEL_FAILURE = False
            else:
                self.mi.LOG_HANDLER('Relief rate was not provided, which is required for this pressure range.  The model will proceed with a Catastrophic Rupture, not following Vessel Overpressure Methodology.')
        else:
            if not self.mi.RELIEF_CALC_AVAILABLE or pd.isna(self.mi.RELIEF_CALC_RATE_KG_S):
                self.mi.LOG_HANDLER('WARNING:  The Vessel Overpressure Methodology calls for use of relief evaluation in this pressure range.\nSince the relief rate was not provided, the rate will be calculated using the provided pressure, temperature and diameter.\nThis may not be as accurate as a detailed relief evaluation.')

    def pressure_factor_1_3_to_2_x_MAWP(self):
        self.mi.LOG_HANDLER('Pressure >= 1.3xMAWP.  Pressure < 2xMAWP.')
        self.mi.LOG_HANDLER('The Vessel Overpressure Methodology specifies a model based on across a half-inch diameter hole')
        if self.mi.CATASTROPHIC_VESSEL_FAILURE:
            self.mi.LOG_HANDLER('WARNING:  The Vessel Overpressure Methodology calls for leak-based evaluation in this Pressure Range.  However, Catastrophic Rupture was selected.')
            self.mi.CATASTROPHIC_VESSEL_FAILURE = False
        if self.mi.RELIEF_CALC_AVAILABLE:
            self.mi.LOG_HANDLER('WARNING:  The Vessel Overpressure Methodology calls for a leak evaluation across a half-inch diameter hole.  However, a release rate was provided.')
            self.mi.RELIEF_CALC_AVAILABLE = False
            self.mi.RELIEF_CALC_RATE_KG_S = None
        if self.mi.MAX_HOLE_SZ_M is None or self.mi.MAX_HOLE_SZ_M != 0.5:
            self.mi.LOG_HANDLER('WARNING:  The Vessel Overpressure Methodology calls for a leak evaluation across a half-inch diameter hole.  However, a different hole diameter was provided.')
        self.mi.LOG_HANDLER('A leak through a half-inch hole will be modeled per Vessel Overpressure Methodology.')
        self.mi.MAX_HOLE_SZ_M = 0.5 / 12 / 3.28084 # half-inch leak
    
    def pressure_factor_at_least_2_x_MAWP(self):
        self.mi.LOG_HANDLER('Pressure >= 2xMAWP.')
        self.mi.LOG_HANDLER('The Vessel Overpressure Methodology defines the appropriate specified leak method based on the stored phase.')
        if self.flashresult.fluid_phase == Phase.LIQUID or self.mi_rp == self.rp_enum.LIQUID:
            self.pressure_factor_at_least_2_x_MAWP_liquid_phase()
            return
        if self.flashresult.fluid_phase == Phase.VAPOUR or self.mi_rp == self.rp_enum.VAPOR:
            self.pressure_factor_at_least_2_x_MAWP_vapor_phase()
            return
        if self.flashresult.fluid_phase == Phase.TWO_PHASE:
            self.pressure_factor_at_least_2_x_MAWP_two_phase()

    def pressure_factor_at_least_2_x_MAWP_liquid_phase(self):
        self.mi.LOG_HANDLER('Liquid-phase release evaluation')
        self.mi.CATASTROPHIC_VESSEL_FAILURE = False
        if not self.mi.RELIEF_CALC_AVAILABLE or pd.isna(self.mi.RELIEF_CALC_RATE_KG_S):
            if pd.isna(self.mi.MAX_HOLE_SZ_M):
                self.mi.LOG_HANDLER('WARNING:  Relief rate and diameter were not provided.  These are required for rate-based evaluations used in liquid overpressure methods.\nIt will be assumed that the vessel will catastrophically fail')
                self.mi.CATASTROPHIC_VESSEL_FAILURE = True
                return
            self.mi.LOG_HANDLER('WARNING:  Relief rate was not provided but diameter is available.  The diameter will be used to estimate release rate which are required for overpressure with liquid.  It is assumed that , which is required for this pressure range and phase per the Vessel Overpressure Methodology.  The model will proceed with a normal target table evaluation, based on the provided inputs.  It will not follow Vessel Overpressure Methodology.')


    def pressure_factor_at_least_2_x_MAWP_vapor_phase(self):
        self.mi.LOG_HANDLER('Vapor-phase release evaluation')
        self.mi.LOG_HANDLER('The Vessel Overpressure Methodology for vapor phase release is defined as a catastrophic vessel failure.')
        if not self.mi.CATASTROPHIC_VESSEL_FAILURE:
            self.mi.LOG_HANDLER('WARNING:  Catastrophic Vessel Failure was not checked on.  This is required for the Vessel Overpressure Methodology, and will be activated.')
            self.mi.CATASTROPHIC_VESSEL_FAILURE = True
            self.mi.RELIEF_CALC_AVAILABLE = False
            self.mi.RELIEF_CALC_RATE_KG_S = None
    
    def pressure_factor_at_least_2_x_MAWP_two_phase(self):
        ll = self.get_liquid_level()
        if ll is not None:
            if ll >= 0.95:
                self.pressure_factor_at_least_2_x_MAWP_liquid_phase()
                return
        self.mi.LOG_HANDLER('Two-phase release evaluation')
        self.mi.LOG_HANDLER('The vessel overpressure methodology for two-phase release is defined as requiring analysis of Catastrophic Failure from the different phases, then selecting the worst case consequences from both.')
        self.high_pressure_two_phase_evaluation_required = True
        self.mi.CATASTROPHIC_VESSEL_FAILURE = True
        self.populate_model_inputs_for_vapor_and_liquid_phases()

    def populate_model_inputs_for_vapor_and_liquid_phases(self):
        if pd.isna(self.py_lopa_flash):
            self.py_lopa_flash = thermo_pio.get_ideal_flash_calc_from_mi(mi=self.mi, cheminfo = self.mi.chems.cheminfo)
        xs = self.py_lopa_flash['xs']
        mi_liquid = copy.deepcopy(self.mi)
        mi_liquid.COMPOSITION = xs
        mi_liquid.TEMP_K -= 1
        mi_liquid.chems = None
        mi_liquid.USE_VESSEL_OVERPRESSURE_METHODOLOGY = False
        mi_liquid.COMPOSITION_IS_IN_MOLES = True
        self.model_inputs_for_both_phases[self.rp_enum.LIQUID] = mi_liquid

        ys = thermo_pio.get_vapor_phase_from_ideal_flash_calc(self.py_lopa_flash)
        mi_vapor = copy.deepcopy(self.mi)
        mi_vapor.COMPOSITION = ys
        mi_vapor.TEMP_K += 1
        mi_vapor.chems = None
        mi_vapor.USE_VESSEL_OVERPRESSURE_METHODOLOGY = False
        mi_vapor.COMPOSITION_IS_IN_MOLES = True
        self.model_inputs_for_both_phases[self.rp_enum.VAPOR] = mi_vapor
        self.get_liquid_and_vapor_masses()
        self.run_vapor_and_liquid_mc()
        self.compare_vapor_and_liquid_results_and_store_most_conservative()
    
    def get_liquid_level(self):
        # using 1 kg basis
        liquid_mass = self.flashresult.liquid_mass_fraction
        if liquid_mass <= 0 or liquid_mass >= 1e20:
            return None
        vapor_mass = 1 - liquid_mass
        liq_rho_kg_m3 = self.flashresult.liquid_density
        if liq_rho_kg_m3 <= 0 or liq_rho_kg_m3 >= 1e20:
            return None
        liquid_volume = liquid_mass / liq_rho_kg_m3
        vap_rho_kg_m3 = self.flashresult.vapour_density
        if vap_rho_kg_m3 <= 0 or vap_rho_kg_m3 >= 1e20:
            return None
        vapor_volume = vapor_mass / vap_rho_kg_m3
        if vapor_volume + liquid_volume == 0:
            return None
        return liquid_volume / (vapor_volume + liquid_volume)




    def get_liquid_and_vapor_masses(self):
        rho_kg_m3 = self.flashresult.total_fluid_density
        if pd.isna(self.mi.STORAGE_MASS_KG):
            self.mi.STORAGE_MASS_KG = self.mi.STORAGE_VOLUME_M3 * rho_kg_m3
        
        if pd.isna(self.mi.STORAGE_VOLUME_M3):
            self.mi.STORAGE_VOLUME_M3 = self.mi.STORAGE_MASS_KG / rho_kg_m3
        
        mass_kg = self.mi.STORAGE_MASS_KG
    
        rho_liquid_kg_m3 = self.flashresult.liquid_density
        liquid_mass_fraction = self.flashresult.liquid_mass_fraction
        mass_liquid_kg = liquid_mass_fraction * mass_kg
        self.model_inputs_for_both_phases[self.rp_enum.LIQUID].STORAGE_MASS_KG = mass_liquid_kg
        self.model_inputs_for_both_phases[self.rp_enum.LIQUID].STORAGE_VOLUME_M3 = 0
        if liquid_mass_fraction > 0:
            self.model_inputs_for_both_phases[self.rp_enum.LIQUID].STORAGE_VOLUME_M3 = mass_liquid_kg / rho_liquid_kg_m3

        rho_vapor_kg_m3 = self.flashresult.vapour_density
        vapor_mass_fraction = 1 - liquid_mass_fraction
        mass_vapor_kg = mass_kg - mass_liquid_kg
        self.model_inputs_for_both_phases[self.rp_enum.VAPOR].STORAGE_MASS_KG = mass_vapor_kg
        self.model_inputs_for_both_phases[self.rp_enum.VAPOR].STORAGE_VOLUME_M3 = 0
        if vapor_mass_fraction > 0:
            self.model_inputs_for_both_phases[self.rp_enum.VAPOR].STORAGE_VOLUME_M3 = mass_vapor_kg / rho_vapor_kg_m3

    def run_vapor_and_liquid_mc(self):
        self.output_data = {
            self.rp_enum.VAPOR: None,
            self.rp_enum.LIQUID: None,
        }
        for phase in [self.rp_enum.VAPOR, self.rp_enum.LIQUID]:
            mi_current = self.model_inputs_for_both_phases[phase]
            mi_current.prep_chems()
            mc = copy.deepcopy(self.mc)
            mc.mi = mi_current
            res = mc.run()
            if res != ResultCode.SUCCESS:
                continue
            self.output_data[phase] = copy.deepcopy(mc.output_list)
        

            
    
    def compare_vapor_and_liquid_results_and_store_most_conservative(self):
        
        res = self.check_for_only_one_result()
        if pd.isna(res):
            return
        if res != "both":
            self.results = self.output_data[res]
            return
        self.analyze_vapor_and_liquid_results()
        
    def check_for_only_one_result(self):
        vap = None
        if self.rp_enum.VAPOR in self.output_data:
            vap = self.output_data[self.rp_enum.VAPOR]
        liq = None
        if self.rp_enum.LIQUID in self.output_data:
            liq = self.output_data[self.rp_enum.LIQUID]
        if pd.isna(vap) and pd.isna(liq):
            return None
        if not pd.isna(vap) and pd.isna(liq):
            return self.rp_enum.VAPOR
        if pd.isna(vap) and not pd.isna(liq):
            return self.rp_enum.LIQUID
        return "both"
        
    def analyze_vapor_and_liquid_results(self):
        results_list = []
        vap_list = self.output_data[self.rp_enum.VAPOR]
        liq_list = self.output_data[self.rp_enum.LIQUID]
        target_list = vap_list
        other_list = liq_list 
        if len(liq_list) > len(vap_list):
            target_list = liq_list
            other_list = vap_list

        completed_release_durations = []
        for i in range(len(target_list)):
            target = None
            release_duration_sec = None
            if isinstance(target_list[i], dict):
                if 'release_duration_sec' not in target_list[i]:
                    continue
                if pd.isna(target_list[i]['release_duration_sec']):
                    continue
                if target_list[i]['release_duration_sec'] in completed_release_durations:
                    continue
                release_duration_sec = target_list[i]['release_duration_sec']
                target = target_list[i]
            other = None
            for j in range(len(other_list)):
                if not isinstance(other_list[j], dict):
                    continue
                if 'release_duration_sec' not in other_list[j]:
                    continue
                if not pd.isna(release_duration_sec):
                    if other_list[j]['release_duration_sec'] != release_duration_sec:
                        continue
                    other = other_list[j]
                    break
                if pd.isna(release_duration_sec):
                    if pd.isna(other_list[j]['release_duration_sec']):
                        continue
                    if other_list[j]['release_duration_sec'] in completed_release_durations:
                        continue
                    other = other_list[j]
                    release_duration_sec = other['release_duration_sec']
                    break
            if pd.isna(target):
                for k in range(len(target_list)):
                    if not isinstance(target_list[k], dict):
                        continue
                    if 'release_duration_sec' not in target_list[k]:
                        continue
                    if not pd.isna(release_duration_sec):
                        if target_list[k]['release_duration_sec'] != release_duration_sec:
                            continue
                        target = target_list[k]
                        break
                    if pd.isna(release_duration_sec):
                        if pd.isna(target_list[k]['release_duration_sec']):
                            continue
                        if target_list[k]['release_duration_sec'] in completed_release_durations:
                            continue
                        target = target_list[k]
                        release_duration_sec = target['release_duration_sec']
                        break

            if pd.isna(release_duration_sec):
                # no identified valid release durations found
                return
            if pd.isna(target) and pd.isna(other):
                # if somehow release duration is set but ther results dicts are both null,
                # no data is available
                return
            if not pd.isna(target) and pd.isna(other):
                results_list.append(target)
                completed_release_durations.append(release_duration_sec)
                continue
            if pd.isna(target) and not pd.isna(other):
                results_list.append(other)
                completed_release_durations.append(release_duration_sec)
                continue

            results_dict = self.compare_impact_levels(target=target, other=other)
            if pd.isna(results_dict):
                results_dict = copy.deepcopy(self.default_data_list[0])
            else:
                results_dict[cd.OUTPUT_DICT_MASS_RELEASED_KG] = self.mi.STORAGE_MASS_KG
            results_list.append(results_dict)
        self.results = results_list
    
    def compare_impact_levels(self, target, other):
        results_dict = copy.deepcopy(self.default_data_list[0])
        ans = self.comparator(target=target, other=other, key='hazard_recs')
        if pd.isna(ans):
            return results_dict
        if ans != 'both':
            results_dict['hazard_recs'] = ans
            return results_dict
        t_hazard_recs = target['hazard_recs']
        o_hazard_recs = other['hazard_recs']
        results_dict = self.compare_onsite_results(results_dict=results_dict, t_hazard_recs=t_hazard_recs, o_hazard_recs=o_hazard_recs)
        results_dict = self.compare_building_results(results_dict=results_dict, t_hazard_recs=t_hazard_recs, o_hazard_recs=o_hazard_recs)
        results_dict = self.compare_offsite_results(results_dict=results_dict, t_hazard_recs=t_hazard_recs, o_hazard_recs=o_hazard_recs)
        return results_dict

        
    
    def compare_onsite_results(self, results_dict, t_hazard_recs, o_hazard_recs):
        ans = self.comparator(target=t_hazard_recs, other=o_hazard_recs, key='onsite')
        if pd.isna(ans):
            return results_dict
        if ans != 'both':
            results_dict['hazard_recs']['onsite'] = ans
            return results_dict
        t_ons = t_hazard_recs['onsite']
        o_ons = o_hazard_recs['onsite']
        
        for wx in cd.WX_ALL_TYPES:
            ans = self.comparator(target=t_ons, other=o_ons, key=wx)
            if pd.isna(ans):
                continue
            if ans != 'both':
                results_dict['hazard_recs']['onsite'][wx] = ans
                continue
            t_ons_wx = t_ons[wx]
            o_ons_wx = o_ons[wx]
            for haz in cd.HAZARD_ALL_TYPES:
                ans_haz = self.comparator(target=t_ons_wx, other=o_ons_wx, key=haz)
                if pd.isna(ans_haz):
                    continue
                if ans_haz != 'both':
                    results_dict['hazard_recs']['onsite'][wx] = ans_haz
                    continue
                t_ons_wx_haz = t_ons_wx[haz]
                o_ons_wx_haz = o_ons_wx[haz]
                haz_result = self.compare_onsite_hazard_results(t_haz=t_ons_wx_haz, o_haz=o_ons_wx_haz)
                if pd.isna(haz_result):
                    continue
                results_dict['hazard_recs']['onsite'][wx][haz] = haz_result
        return results_dict

    def compare_onsite_hazard_results(self, t_haz, o_haz):
        # first compare cat plus poe.  this is the category score adjusted by probability of exposure credit
        ans = self.comparator(target = t_haz, other=o_haz, key='cat_plus_poe')
        if pd.isna(ans):
            return None
        if ans != 'both':
            return ans
        t_cat_plus_poe = t_haz['cat_plus_poe']
        o_cat_plus_poe = o_haz['cat_plus_poe']
        if float(t_cat_plus_poe) > float(o_cat_plus_poe):
            return t_haz
        if float(t_cat_plus_poe) < float(o_cat_plus_poe):
            return o_haz
        
        # when cat plus poe tie, compare raw category score (0 - Minor, 4 - Catastrophic).
        ans_cat = self.comparator(target=t_haz, other=o_haz, key='category')
        if pd.isna(ans_cat):
            return None
        if ans_cat != 'both':
            return ans_cat
        t_cat = t_haz['category']
        o_cat = o_haz['category']
        cat_comparison = self.compare_categories(t_cat=t_cat, o_cat=o_cat)
        if cat_comparison == 'target':
            return t_haz
        if cat_comparison == 'other':
            return o_cat

        # if cat plus poe and raw category tie, finally compare impact area
        ans_impact_area = self.comparator(target=t_haz, other=o_haz, key='impact_area_m2')
        if pd.isna(ans_impact_area):
            return None
        if ans_impact_area != 'both':
            return ans_impact_area
        t_impact_area = t_haz['impact_area_m2']
        o_impact_area = o_haz['impact_area_m2']
        if t_impact_area >= o_impact_area:
            # arbitrarily return t_haz in the event of a tie.
            return t_haz
        if t_impact_area < o_impact_area:
            return o_haz
        
        return None
        
    def compare_building_results(self, results_dict, t_hazard_recs, o_hazard_recs):
        ans_bldgs = self.comparator(target=t_hazard_recs, other=o_hazard_recs, key="building")
        if pd.isna(ans_bldgs):
            return results_dict
        if ans_bldgs != 'both':
            return ans_bldgs
        
        t_bldgs = t_hazard_recs['building']
        o_bldgs = o_hazard_recs['building']
        
        for wx in cd.WX_ALL_TYPES:
            ans_wx = self.comparator(target=t_bldgs, other=o_bldgs, key=wx)
            if pd.isna(ans_wx):
                continue
            if ans_wx != 'both':
                results_dict['hazard_recs']['building'][wx] = ans_wx
                continue
            t_bldgs_wx = t_bldgs[wx]
            o_bldgs_wx = o_bldgs[wx]

            # assuming that comparative result dicts have the same number of buildings.
            for i in range(len(t_bldgs_wx)):
                t_bldg = t_bldgs_wx[i]
                o_bldg = o_bldgs_wx[i]
                for haz in cd.HAZARD_ALL_TYPES:
                    ans_haz = self.comparator(target=t_bldg, other=o_bldg, key=haz)
                    if pd.isna(ans_haz):
                        continue
                    if ans_haz != 'both':
                        results_dict['hazard_recs']['building'][wx][i][haz] = ans_haz[haz]
                        continue
                    t_cat = t_bldg[haz]
                    o_cat = o_bldg[haz]
                    cat_comparison = self.compare_categories(t_cat=t_cat, o_cat=o_cat, tie_returns_target=True)
                    if cat_comparison == 'target':
                        results_dict['hazard_recs']['building'][wx][i][haz] = t_bldg[haz]
                    if cat_comparison == 'other':
                        results_dict['hazard_recs']['building'][wx][i][haz] = o_bldg[haz]
        return results_dict

    def compare_offsite_results(self, results_dict, t_hazard_recs, o_hazard_recs):
        ans = self.comparator(target=t_hazard_recs, other=o_hazard_recs, key="offsite")
        if pd.isna(ans):
            return results_dict
        if ans != 'both':
            return ans
        t_offs = t_hazard_recs['offsite']
        o_offs = o_hazard_recs['offsite']
        for wx in cd.WX_ALL_TYPES:
            ans_wx = self.comparator(target=t_offs, other=o_offs, key=wx)
            if pd.isna(ans_wx):
                continue
            if ans_wx != 'both':
                results_dict['hazard_recs']['offsite'][wx] = ans_wx
                continue
            t_offs_wx = t_offs[wx]
            o_offs_wx = o_offs[wx]
            for haz in cd.HAZARD_ALL_TYPES:
                ans_haz = self.comparator(target=t_offs_wx, other=o_offs_wx, key=haz)
                if pd.isna(ans_haz):
                    continue
                if ans_haz != 'both':
                    results_dict['hazard_recs']['offsite'][wx][haz] = ans_haz
                    continue
                t_cat = t_offs_wx[haz]
                o_cat = o_offs_wx[haz]
                cat_comparison = self.compare_categories(t_cat=t_cat, o_cat=o_cat, tie_returns_target=True)
                if cat_comparison == 'target':
                    results_dict['hazard_recs']['offsite'][wx][haz] = t_cat
                if cat_comparison == 'other':
                    results_dict['hazard_recs']['offsite'][wx][haz] = o_cat
        return results_dict


    def compare_categories(self, t_cat, o_cat, tie_returns_target = False):
        cats_enum = cd.CAT_ALL_CATEGORIES_ENUM
        t_cat_enum_member = cats_enum[t_cat]
        o_cat_enum_member = cats_enum[o_cat]
        t_cat_enum_value = t_cat_enum_member.value
        o_cat_enum_value = o_cat_enum_member.value
        if t_cat_enum_value > o_cat_enum_value:
            return 'target'
        if t_cat_enum_value < o_cat_enum_value:
            return 'other'
        if tie_returns_target and t_cat_enum_value == o_cat_enum_value:
            return 'target'
        return None

    def comparator(self, target, other, key):
        t_val = None
        if key in target:
            t_val = target[key]
        o_val = None
        if key in other:
            o_val = other[key]
        t_val_is_empty_list = False
        o_val_is_empty_list = False
        if isinstance(t_val, list) and len(t_val) == 0:
            t_val_is_empty_list = True
        if isinstance(o_val, list) and len(o_val) == 0:
            o_val_is_empty_list = True
        if t_val_is_empty_list and o_val_is_empty_list:
            return None
        if not t_val_is_empty_list and o_val_is_empty_list:
            if isinstance(t_val, list):
                return target
        if t_val_is_empty_list and not o_val_is_empty_list:
            if isinstance(o_val, list):
                return other
        if not t_val_is_empty_list and not o_val_is_empty_list:
            if isinstance(t_val, list) and isinstance(o_val, list):
                return 'both'
            
        if pd.isna(t_val) and pd.isna(o_val):
            return None
        if not pd.isna(t_val) and pd.isna(o_val):
            return target
        if pd.isna(t_val) and not pd.isna(o_val):
            return other
        return 'both'








