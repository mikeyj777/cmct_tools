import numpy as np
import math


from py_lopa.calcs.consts import Consts, Wx_Enum
from py_lopa.calcs import helpers

class Pasquill_Gifford_Dispersion_Calcs:
    STAB_CLASS_A = 'A'
    STAB_CLASS_B = 'B'
    STAB_CLASS_C = 'C'
    STAB_CLASS_D = 'D'
    STAB_CLASS_E = 'E'
    STAB_CLASS_F = 'F'

    SIGMA_Y_CONTINUOUS_CONSTS = {
        STAB_CLASS_A: [0.493, 0.88],
        STAB_CLASS_B: [0.337, 0.88],
        STAB_CLASS_C: [0.195, 0.9],
        STAB_CLASS_D: [0.128, 0.9],
        STAB_CLASS_E: [0.091, 0.91],
        STAB_CLASS_F: [0.067, 0.9]
    }

    SIGMA_Z_CONTINUOUS_CONSTS = {
        STAB_CLASS_A: [
            [0.087, 1.1],
            [-1.67, 0.902, 0.181]
        ],
        STAB_CLASS_B: [
            [0.135, 0.95],
            [-1.25, 1.09, 0.0018]
        ],
        STAB_CLASS_C: [
            [0.112, 0.91],
        ],
        STAB_CLASS_D: [
            [0.093, 0.85],
            [-1.22, 1.08, -0.061]
        ],
        STAB_CLASS_E: [
            [0.082, 0.82],
            [-1.19, 1.04, -0.07]
        ],
        STAB_CLASS_F: [
            [0.057, 0.8],
            [-1.91, 1.37, -0.119]
        ]
    }

    SIGMA_Z_CONTINUOUS_THRESHOLD_M = {
        STAB_CLASS_A: 300,
        STAB_CLASS_B: 500,
        STAB_CLASS_C: np.inf,
        STAB_CLASS_D: 500,
        STAB_CLASS_E: 500,
        STAB_CLASS_F: 500
    }
    
    SIGMA_Y_PUFF_CONSTS = {
        STAB_CLASS_A: [0.019340632149401100, 0.900012691292788000],
        STAB_CLASS_B: [0.019340632149401100, 0.900012691292788000],
        STAB_CLASS_C: [0.041125047724643500, 0.974585350124386000],
        STAB_CLASS_D: [0.041125047724643500, 0.974585350124386000],
        STAB_CLASS_E: [0.100546265475045000, 0.983230234421084000],
        STAB_CLASS_F: [0.100546265475045000, 0.983230234421084000],
    }

    SIGMA_Z_PUFF_CONSTS = {
        STAB_CLASS_A: [0.05346928270036450, 0.58990400319856000],
        STAB_CLASS_B: [0.05346928270036450, 0.58990400319856000],
        STAB_CLASS_C: [0.16984915453983600, 0.68183410283535500],
        STAB_CLASS_D: [0.16984915453983600, 0.68183410283535500],
        STAB_CLASS_E: [0.13280214642146300, 0.85769947880692600],
        STAB_CLASS_F: [0.13280214642146300, 0.85769947880692600],
    }

    STAB_CLASS_BY_WX_CONDITION = {
        Wx_Enum.DAY: STAB_CLASS_D,
        Wx_Enum.NIGHT: STAB_CLASS_F
    }

    def __init__(self, ta = None) -> None:
        self.release_rate_g_s = None
        self.release_mass_g = None
        if ta is not None:
            self.continuous_release = not ta.mi.CATASTROPHIC_VESSEL_FAILURE
            if self.continuous_release:    
                self.release_rate_g_s = ta.estimate_mass_flow_kg_s * 1000
            else:
                self.release_mass_g = ta.estimate_mass_released_kg * 1000
                
            
            self.mw = helpers.get_mw(ta.cas_no, cheminfo=ta.cheminfo)
        self.data_for_kml_zxy = None

    def get_conc_g_m3_from_conc_ppm(self, conc_ppm):
        return conc_ppm * self.mw / 24450

    def get_total_impacted_area_m2(self, wx_enum, x, conc_ppm, time_min = None):

        # a person fleeing from within the exlusion zone will have too high of a dose and will potentially have a severe injury.
        # the "Toxicological_Analysis" class is sending the downwind distance and time after which the release occurred from where the individual
        # has started fleeing.  the point recorded where an individual can safely flee is given as the distance here.  
        # the concentration upwind of this is considered the exclusion zone.  This is using a pasquill-gifford methodology to esimate the area of the zone where
        # concentration is significant enough that fleeing could result in severe injury.

        x_dists = np.linspace(x/100, x, 100)
        y_at_x_vect = np.vectorize(self.get_y_at_x_m)
        y_dists = y_at_x_vect(wx_enum, x_dists, conc_ppm, time_min)
        z = np.zeros((x_dists.shape[0],))
        self.data_for_kml_zxy = np.vstack((z, x_dists, y_dists)).T
        half_area = np.trapz(y = y_dists, x = x_dists)
        tot_area = 2 * half_area

        return tot_area

    def get_y_at_x_m(self, wx_enum, x, conc_ppm, time_min):
        conc_gm3 = self.get_conc_g_m3_from_conc_ppm(conc_ppm)
        y = 0
        if self.continuous_release:
            y = self.get_y_at_x_m_continuous(wx_enum, x, conc_gm3)
            return y
        if time_min is None:
            return y
        
        time_sec = time_min / 60
        
        y = self.get_y_at_x_m_puff(wx_enum, x, conc_gm3, time_sec)

        return y
        
    def get_y_at_x_m_continuous(self, wx_enum, x, conc_gm3):
        u = Consts.WIND_SPEED_DEFAULT_MS
        stab_class = self.STAB_CLASS_BY_WX_CONDITION[wx_enum]
        sigma_y = self.sigma_y_continuous(stab_class, x)
        sigma_z = self.sigma_z_continuous(stab_class, x)
        ans = 0
        try:
            # solving for 'y' in equation 5-47 in Crowl & Louvar - p.142
            ans = sigma_y * math.sqrt(-2*math.log(conc_gm3 * math.pi * sigma_y * sigma_z * u / self.release_rate_g_s))
        except:
            print(f'error in calculating crosswind distance for continuous release.  dw dist {x} meters.  stab class {stab_class}.')
        return ans

    def get_y_at_x_m_puff(self, wx_enum, x, conc_gm3, time_sec):
        u = Consts.WIND_SPEED_DEFAULT_MS
        stab_class = self.STAB_CLASS_BY_WX_CONDITION[wx_enum]
        sigma_y = self.sigma_y_puff(stab_class, x)
        sigma_z = self.sigma_z_puff(stab_class, x)
        ans = 0
        try:
            # solving for 'y' in equation 5-39 in Crowl & Louvar - p.141
            alpha = conc_gm3 * math.sqrt(2) * (math.pi ** 1.5) * (sigma_y ** 2) * sigma_z / self.release_mass_g
            ans = math.sqrt(-(2*(sigma_y**2)*math.log(alpha) + (x - u * time_sec) **2))
            apple = 1
        except:
            print(f'error in calculating crosswind distance for puff release.  dw dist {x} meters.  stab class {stab_class}.')
        return ans

    def sigma_y_continuous(self, stab_class, x, consts_for_plume_back_calc = []):
        # in the case where the constants are being back-calculated, the current iterated guess will be provided.
        # stability class is ignored while back calculating.

        consts = consts_for_plume_back_calc
        if len(consts_for_plume_back_calc) == 0:
            consts = self.SIGMA_Y_CONTINUOUS_CONSTS[stab_class]
        a = consts[0]
        b = consts[1]
        ans = -1
        try:
            ans = a * (x ** b)
        except:
            print(f'bad value for sigma y continuous calc.  dw dist {x} meters.  stab class {stab_class}.')
        return ans

    def sigma_z_continuous(self, stab_class, x, consts_for_plume_back_calc = []):
        # in the case where the constants are being back-calculated, the current iterated guess will be provided.
        # stability class is ignored while back calculating.
        
        consts_matrix = consts_for_plume_back_calc
        threshold = np.inf
        if len(consts_for_plume_back_calc) == 0:
            threshold = self.SIGMA_Z_CONTINUOUS_THRESHOLD_M[stab_class]
            consts_matrix = self.SIGMA_Z_CONTINUOUS_CONSTS[stab_class]
        if x <= threshold:
            ans = -1
            consts_row = consts_matrix[0]
            a = consts_row[0]
            b = consts_row[1]
            try:
                ans = a * (x ** b)
            except:
                print(f'bad value for sigma z continuous calc.  dw dist {x} meters.  stab class {stab_class}.')
            return ans
    
        ans = -1
        consts_row = consts_matrix[1]
        a = consts_row[0]
        b = consts_row[1]
        c = consts_row[2]
        try:
            exponent = a + b * math.log10(x) + c * (math.log10(x))**2
            ans = 10 ** exponent
        except:
            print(f'bad value for sigma z calc.  dw dist {x} meters.  stab class {stab_class}.')
        return ans

    def sigma_y_puff(self, stab_class, x):
        consts = self.SIGMA_Y_PUFF_CONSTS[stab_class]
        a = consts[0]
        b = consts[1]
        ans = -1
        try:
            ans = math.exp(a * math.log(x) + b)
        except:
            print(f'bad value for sigma y puff calc.  dw dist {x} meters.  stab class {stab_class}.')
        return ans

    def sigma_z_puff(self, stab_class, x):
        consts = self.SIGMA_Z_PUFF_CONSTS[stab_class]
        a = consts[0]
        b = consts[1]
        ans = -1
        try:
            ans = math.exp(a * math.log(x) + b)
        except:
            print(f'bad value for sigma z puff calc.  dw dist {x} meters.  stab class {stab_class}.')
        return ans

