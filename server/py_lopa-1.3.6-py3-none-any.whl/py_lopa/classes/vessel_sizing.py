import sys
import math

from pypws.enums import ResultCode, Phase

from py_lopa.data.exception_enum import Exception_Enum
from py_lopa.classes.vessel_dimension_specification import Vessel_Dimension_Specification
from py_lopa.calcs import helpers
from py_lopa.calcs.consts import Consts

class Vessel_Sizing:

    def __init__(self, chems=None, mi=None, flashresult=None, release_duration_sec = 3600, mass_flow_kg_s = -1):
        self.chems = chems
        self.mi = mi
        self.flashresult = flashresult
        self.release_duration_sec = release_duration_sec
        self.tank_elevation_above_grade_m = 0
        self.mass_flow_kg_s = mass_flow_kg_s

    def get_sizing_and_leak_height(self):

        # building a psuedo vessel:
        # total release time 1 hr at press/temp/max hole size
        

        # per Maria Fernandez (DNV), the ground level release positions liquid into a pool.  
        # Elevated releases generate more vapor due to increased surface area of falling fluid.  Wayne Chastain (Eastman Sr Associate) feels this is accurate.

        # if self.flashresult.fluidPhase == Phase.LIQUID:
        #     self.mi.RELEASE_ELEVATION_M = 0

        ht_m = self.mi.RELEASE_ELEVATION_M
        if ht_m == 0:
            ht_m = 10

        self.vds = Vessel_Dimension_Specification(mi = self.mi, flashResult = self.flashresult)

        if self.vds.get_specs() != ResultCode.SUCCESS:
            raise Exception(Exception_Enum.INVALID_PHASE_SPECIFICATION)
        
        rho_kgm3 = self.vds.rho_kgm3
        leak_height_fract_of_vessel = self.vds.leak_height_fract_of_vessel
        vc = self.vds.vc
        liquid_fill_fract = self.vds.liquid_fill_fract

        if self.mi.STORAGE_VOLUME_M3 is None:
            self.mi.STORAGE_VOLUME_M3 = self.mi.STORAGE_MASS_KG / rho_kgm3
        
        if self.mi.STORAGE_MASS_KG is None:
            self.mi.STORAGE_MASS_KG = self.mi.STORAGE_VOLUME_M3 * rho_kgm3

        mass_released_kg = self.mi.STORAGE_MASS_KG
        vol_released_m3 = self.mi.STORAGE_VOLUME_M3
        self.rho_kgm3 = rho_kgm3
        
        if self.mi.CATASTROPHIC_VESSEL_FAILURE:
            self.set_diam_ht_elev_above_ground_meters(vol_released_m3=vol_released_m3, vessel_dimension_specifications = self.vds)
            self.liquid_fill = liquid_fill_fract
            self.vessel_condition = vc
            self.stop_after_this_release = True
            self.mass_released_kg = mass_released_kg
            self.leak_height = self.vds.leak_height_fract_of_vessel

            return

        # on the first pass, the vessel leak discharge rate hasn't been calculated.  The vessel is sized to hold the full inventory
        vol_released_m3 = self.mi.STORAGE_VOLUME_M3
        mass_released_kg = vol_released_m3 * rho_kgm3
        if self.mass_flow_kg_s > 0:
            mass_released_kg = self.mass_flow_kg_s * self.release_duration_sec
            vol_released_m3 = mass_released_kg / rho_kgm3

        stop_after_this_release = False
        if self.mass_flow_kg_s > 0 and vol_released_m3 > self.mi.STORAGE_VOLUME_M3: # * (1 + Consts.TOLERANCE_PERCENT_GENERAL):  # not sure why I was using a tolerance here.
            self.mi.LOG_HANDLER(f'The volume specified by user, {self.mi.STORAGE_VOLUME_M3} m3, is less than the amount which will be released in {int(self.release_duration_sec / 60)} minutes.')
            self.mi.LOG_HANDLER(f'The model will be updated to analyze the user-specified volume.')

            vol_released_m3 = self.mi.STORAGE_VOLUME_M3
            mass_released_kg = vol_released_m3 * rho_kgm3
            stop_after_this_release = True
            self.release_duration_sec = mass_released_kg / self.mass_flow_kg_s
            
        self.set_diam_ht_elev_above_ground_meters(vol_released_m3=vol_released_m3, vessel_dimension_specifications = self.vds)
        
        self.vessel_condition = vc
        self.liquid_fill = liquid_fill_fract
        self.leak_height = leak_height_fract_of_vessel
        self.stop_after_this_release = stop_after_this_release
        self.mass_released_kg =  mass_released_kg

    def set_diam_ht_elev_above_ground_meters(self, vol_released_m3, vessel_dimension_specifications, hole_sz_m = -1):
        if hole_sz_m < 0:
            if self.mi is None:
                raise Exception(Exception_Enum.INVALID_HOLE_SIZE_DESIGNATION)
            hole_sz_m = self.mi.MAX_HOLE_SZ_M
        vds = vessel_dimension_specifications
        vess_vol_mult = vds.vessel_vol_multiplier

        vessel_vol_m3 = vol_released_m3 * vess_vol_mult

        l_by_d = Consts.L_BY_D
        diam_m = (4* vessel_vol_m3 / math.pi / l_by_d)**(1/3)
        ht_m = diam_m * l_by_d

        if hole_sz_m is not None:
            if diam_m < hole_sz_m / Consts.MAX_HOLE_SIZE_IN_PCT_OF_VESSEL_DIAM:
                diam_m = hole_sz_m / Consts.MAX_HOLE_SIZE_IN_PCT_OF_VESSEL_DIAM
                ht_m = 4 * vessel_vol_m3 / math.pi / (diam_m**2)

        leak_height_fract_of_vessel = vds.leak_height_fract_of_vessel
        height_of_leak_above_btm_of_vessel = ht_m * leak_height_fract_of_vessel
        tank_elevation_above_grade_m = self.mi.RELEASE_ELEVATION_M - height_of_leak_above_btm_of_vessel
        
        self.diam_m = diam_m
        self.height_m = ht_m

        self.tank_elevation_above_grade_m = tank_elevation_above_grade_m

