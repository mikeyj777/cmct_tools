import csv
import math
import random
import numpy as np
import pandas as pd
from scipy.interpolate import griddata
from scipy import integrate
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

from pypws.calculations import DispersionCalculation, LateExplosionCalculation, DistancesAndFootprintsToConcentrationLevelsCalculation
from pypws.entities import ExplosionConfinedVolume, DispersionOutputConfig, ExplosionOutputConfig, ExplosionParameters
from pypws.enums import Resolution, SpecialConcentration, MEConfinedMethod, ResultCode

from py_lopa.calcs import helpers
from py_lopa.calcs.integrator import Integrator
from py_lopa.data.tables import Tables
from py_lopa.calcs.geospatial import distance_in_meters_between_lat1_long1_and_lat2_long_2
from py_lopa.calcs.tno_multienergy_blast_correlations import get_psc_given_blast_strength_class_and_scaled_radius

class VCE:

    def __init__(self, phast_dispersion = None, save_pickles = False) -> None:
        self.zxys_df = {}
        self.phast_dispersion = phast_dispersion
        if save_pickles:
            self.save_pickles()
        self.targ_concs = []
        self.dispersionCalculation = None
        self.mi = None
        self.flash_data = None
        if self.phast_dispersion is not None:
            lfl = self.phast_dispersion.ep_conc
            self.targ_concs = [lfl]
            self.dispersionCalculation = phast_dispersion.dispersionCalculation
            self.mi = phast_dispersion.mi
            self.flash_data = self.phast_dispersion.chems.flash_data
        self.flammable_mass_g = None
        self.flammable_mass_results = None
        self.max_dw_extent = None
        self.flammable_envelope_list_of_dicts = []
        self.flammable_envelope_df = {}
    
    def get_overall_flammable_envelope_and_maximum_downwind_extent(self):
        self.get_conc_targets_between_lfl_and_pure_conc()
        resp = self.run_dispersion_model_inside_flammable_envelope()
        
        if resp != ResultCode.SUCCESS:
            self.phast_dispersion.mi.LOG_HANDLER('VCE flammable envelope model did not complete successfully')
            return
        self.phast_dispersion.mi.LOG_HANDLER('VCE flammable envelope model completed OK')

        self.parse_flam_env_contour_points()

        return {
            'flammable_envelope_list_of_dicts': self.flammable_envelope_list_of_dicts,
            'maximum_downwind_extent': self.max_dw_extent,
            'flash_data': self.flash_data,
        }
    
    def save_pickles(self):
        helpers.save_object_as_pickle_return_path_and_file_name(self.phast_dispersion, descr='p_disp', out_dir='../vce_testing/', use_time_stamp=False)
    
    def get_conc_targets_between_lfl_and_pure_conc(self):
        # concentrations exponentially increasing from lfl to pure conc over 6 values:  1e6 = lfl * factor^6 
        lfl = self.targ_concs[0]
        self.targ_concs = np.linspace(lfl, 0.99, 10).tolist()
        low_end_concs = np.linspace(lfl, self.targ_concs[1], 10).tolist()
        self.targ_concs.extend(low_end_concs)
        self.targ_concs.sort()
        

    def run_dispersion_model_inside_flammable_envelope(self):
        self.phast_dispersion.run_footprint_models_for_vce(self.targ_concs)

        return self.phast_dispersion.distancesAndFootprintsCalc.result_code
    
    def parse_flam_env_contour_points(self):
        dists_and_concs:DistancesAndFootprintsToConcentrationLevelsCalculation = self.phast_dispersion.distancesAndFootprintsCalc
        n_contour_points = dists_and_concs.n_contour_points
        data = []
        cp_idx_start = 0
        cps = dists_and_concs.contour_points
        for i in range(len(n_contour_points)):
            if n_contour_points[i] == 0:
                continue
            dispOutputCfg:DispersionOutputConfig = dists_and_concs.dispersion_output_configs[i]
            conc = dispOutputCfg.concentration
            if conc is None:
                conc = 0
            cp_count = n_contour_points[i]
            curr_cp_range = cps[cp_idx_start:cp_idx_start+cp_count]
            for cp in curr_cp_range:
                x = cp.x
                y = cp.y
                z = cp.z
                data.append({
                    'x': x,
                    'y': y,
                    'z': z,
                    'conc_ppm': conc * 1e6
                })
            cp_idx_start += cp_count
        
        if len(data) == 0:
            data.append({
                'x': 0,
                'y': 0,
                'z': 0,
                'conc_ppm': 0
            })
        df = pd.DataFrame(data)
        
        df = df[(df['x'] > -10000) & (df['x'] < 10000)]

        # concGm3 = concPpm * mWt / 24450
        ys = np.array(self.flash_data['ys'])
        mws = np.array(self.flash_data['mws'])
        ave_mw_vap = ys.dot(mws.T)
        df['conc_g_m3'] = df['conc_ppm'] * ave_mw_vap / 24450
        self.flammable_envelope_df = df
        self.flammable_envelope_list_of_dicts = df.to_dict(orient='records')
        x_min = df['x'].min()
        x_max = df['x'].max()
        self.max_dw_extent=max(abs(x_min), abs(x_max))

    def get_flammable_mass(self, x_min = None, x_max = None, y_min = None, y_max = None, z_min = None, z_max = None, flammable_envelope_list_of_dicts = None):
        if flammable_envelope_list_of_dicts is None:
            flammable_envelope_df = self.flammable_envelope_df
        else:
            flammable_envelope_df = pd.DataFrame(flammable_envelope_list_of_dicts)

        integrator = Integrator()
        integrator.load_data(flammable_envelope_df)
        results = integrator.integrate(x_min=x_min, x_max=x_max, y_min=y_min, y_max=y_max, z_min=z_min, z_max=z_max)
        self.flammable_mass_g = results['total_mass_g']
        self.flammable_mass_results = results
        return {
            'flammable_mass_g': self.flammable_mass_g,
            'flammable_mass_results': self.flammable_mass_results,
        }

    def plot_flammable_envelope(self):
        df = self.flammable_envelope_df
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')

        sc = ax.scatter(df['x'], df['y'], df['z'], c=df['conc_ppm'], cmap='viridis')

        plt.colorbar(sc)
        ax.set_xlabel('X Axis')
        ax.set_ylabel('Y Axis')
        ax.set_zlabel('Z Axis')

        plt.show()

    def get_mixture_reactivity_0_low_1_med_2_high(self, flash_data = None):
        if flash_data is None:
            flash_data = self.flash_data
        if self.flash_data is None:
            return -1
        burning_velocity_df = helpers.get_dataframe_from_csv(Tables().LAMINAR_BURNING_VELOCITY_DATA)
        chem_mix = flash_data['chem_mix']
        ys = flash_data['ys']
        burn_veloc_denom = 0
        mixture_burning_velocity_m_s = 0
        for i in range(len(chem_mix)):
            row = burning_velocity_df[burning_velocity_df['cas'] == chem_mix[i]]
            if len(row) == 0:
                continue
            burning_veloc_m_s = helpers.get_data_from_pandas_series_element(row['burning_velocity_m_s'])
            if burning_veloc_m_s == 0:
                continue
            burn_veloc_denom += ys[i]/burning_veloc_m_s
        if burn_veloc_denom > 0:
            mixture_burning_velocity_m_s = 1 / burn_veloc_denom
        reactivity = 1
        if mixture_burning_velocity_m_s >= 0.75:
            reactivity = 2
        if mixture_burning_velocity_m_s < 0.45:
            reactivity = 0
        return reactivity
        
    def get_blast_strength_for_congested_volume(self, congested_volume, reactivity):
        """
        Basis - Table 5.3 Initial Blast strength index - TNO Yellow Book, p. 510

        Determine blast strength class based on reactivity, congestion level, and confinement.
        
        Parameters:
        - reactivity: int (0=Low, 1=Medium, 2=High)
        - congestion_level: int (0=No, 1=Low, 2=High)
        - is_indoors: bool (True=Confined, False=Unconfined)
        
        Returns:
        - int: The blast strength class (higher end of the range)
        """
        is_indoors = congested_volume['isIndoors']
        congestion_level = congested_volume['congestionLevel']
        
        
        # High Reactivity (2)
        if reactivity == 2:
            # High Congestion (2)
            if congestion_level == 2:
                if is_indoors:  # Confined
                    return 10  # Class 7-10
                else:  # Unconfined
                    return 9  # Class 7-10
            # Low Congestion (1)
            elif congestion_level == 1:
                if is_indoors:  # Confined
                    return 7   # Class 5-7
                else:  # Unconfined
                    return 6   # Class 4-6
            # No Congestion (0)
            else:
                if is_indoors:  # Confined
                    return 6   # Class 4-6
                else:  # Unconfined (this case isn't explicitly in the table)
                    return 5   # Class 4-5 (based on row 8, assuming confined)
        
        # Medium Reactivity (1) - interpolated
        elif reactivity == 1:
            # High Congestion (2)
            if congestion_level == 2:
                if is_indoors:  # Confined
                    return 9   # Between class 7-10
                else:  # Unconfined
                    return 8   # Between class 7-10
            # Low Congestion (1)
            elif congestion_level == 1:
                if is_indoors:  # Confined
                    return 6   # Between class 5-7
                else:  # Unconfined
                    return 5   # Between class 4-6
            # No Congestion (0)
            else:
                if is_indoors:  # Confined
                    return 5   # Between class 4-6
                else:  # Unconfined
                    return 4   # Between class 1-4
        
        # Low Reactivity (0)
        else:
            # High Congestion (2)
            if congestion_level == 2:
                if is_indoors:  # Confined
                    return 7   # Class 5-7
                else:  # Unconfined
                    return 5   # Class 4-5
            # Low Congestion (1)
            elif congestion_level == 1:
                if is_indoors:  # Confined
                    return 5   # Class 3-5
                else:  # Unconfined
                    return 3   # Class 2-3
            # No Congestion (0)
            else:
                if is_indoors:  # Confined
                    return 2   # Class 1-2
                else:  # Unconfined
                    return 1   # Class 1

    def get_heat_of_combustion_J(self, flash_data, flammable_mass_g):
        ys = np.array(flash_data['ys'])
        mws = np.array(flash_data['mws'])
        chem_mix = flash_data['chem_mix']
        ave_mw_vap = ys.dot(mws.T)
        df = helpers.get_dataframe_from_csv(Tables().DIPPR_CONSTANTS)
        h_comb_j_kmol_total = 0
        for i in range(len(chem_mix)):
            h_comb_j_kmol_element = df[(df['cas_no'] == chem_mix[i]) & (df['property_id'] == 'hcom')]
            h_comb_j_kmol = h_comb_j_kmol_element['value'].max()
            h_comb_j_kmol_total += h_comb_j_kmol * ys[i]
        h_comb_j_kg_total = h_comb_j_kmol_total * ave_mw_vap
        h_comb_j = abs(h_comb_j_kg_total * flammable_mass_g / 1000)
        return h_comb_j

    def get_blast_overpressures_at_buildings_from_congested_volumes_store_highest_pressure_at_each_building_return_updated_buildings(self, buildings, congested_volumes, flash_data = None):
        if flash_data is None:
            flash_data = self.flash_data
        if self.flash_data is None:
            return buildings
        reactivity = self.get_mixture_reactivity_0_low_1_med_2_high(flash_data=flash_data)
        for cv in congested_volumes:
            flammable_mass_g = cv['flammableMassG']
            if flammable_mass_g == 0:
                continue
            h_comb_j = self.get_heat_of_combustion_J(flash_data, flammable_mass_g)
            blast_strength_class = self.get_blast_strength_for_congested_volume(congested_volume=cv, reactivity=reactivity)
            cv_position = cv['position']
            lat1 = cv_position['lat']
            lng1 = cv_position['lng']
            for bldg in buildings:
                bldg_position = bldg['location']
                lat2 = bldg_position['lat']
                lng2 = bldg_position['lng']
                dist_m_from_cv_to_bldg = distance_in_meters_between_lat1_long1_and_lat2_long_2(lat1, lng1, lat2, lng2)
                scaled_r = dist_m_from_cv_to_bldg / (h_comb_j / 101325) ** (1/3) # eqn 5.2 in TNO Yellow Book - p. 507
                scaled_p = get_psc_given_blast_strength_class_and_scaled_radius(tnoClass=blast_strength_class, scaled_radius=scaled_r)
                p_Pa_side_on = scaled_p * 101325 # yellow book eqn 5.3
                p_Pa_side_on_and_reflected = p_Pa_side_on * 2
                overpressure_psi = p_Pa_side_on_and_reflected * 14.6959 / 101325
                if 'max_overpressure_psi' not in bldg:
                    bldg['max_overpressure_psi'] = overpressure_psi
                
                bldg['max_overpressure_psi'] = max(bldg['max_overpressure_psi'], overpressure_psi)
        
        return buildings



        



