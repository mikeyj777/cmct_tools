import pandas as pd
import numpy as np

# from py_lopa.phast_io.phast_dispersion import Phast_Dispersion
# from py_lopa.phast_io.phast_discharge import Phast_Discharge
from py_lopa.calcs.flattening import Flattening
from py_lopa.calcs import helpers
from py_lopa.calcs.consts import Consts

cd = Consts().CONSEQUENCE_DATA

class DNV_Test_Results:

    def __init__(self, phast_disp, conseq_assess):
        self.phast_dispersion = phast_disp
        self.flattening = Flattening()
        self.max_dist_at_conc_results_df = {}
        self.max_conc_footprint_results_df = {}
        self.distances_to_thresholds = {}
        self.ca = conseq_assess
        self.flattened_impact_areas_m2 = {}

    def run(self):
        self.get_max_conc_distance_results()
        self.get_max_conc_footprint_areas()
        self.get_distances_to_thresholds_all_haz_types()
        self.get_overall_area_results()
        if len(self.distances_to_thresholds) == 0:
            self.distances_to_thresholds = None



    def get_max_conc_distance_results(self):
        if not hasattr(self.phast_dispersion, "conc_profiles"):
            return
        if len(self.phast_dispersion.conc_profiles) == 0:
            return
        
        max_conc_at_elevations = self.phast_dispersion.conc_profiles
        conc_for_output_ppm = self.phast_dispersion.ep_conc * 1e6
        conc_for_output_ppm = helpers.float_value_rounded_to_x_sig_figs(conc_for_output_ppm, 4)

        self.flattening.conc_pfls = max_conc_at_elevations
        zxyc = self.flattening.get_zxyc_array_from_conc_pfls_bet_min_and_max_elevation(min_ht_m=0, max_ht_m=6)
        zxyc_df = pd.DataFrame(zxyc, columns = list('zxyc'))
        zxyc_df = zxyc_df.sort_values(by='x')
        
        output = []
        for elev in [0,6]:
            zxyc_at_elev = zxyc_df[zxyc_df['z'] == elev]
            x = self.get_x_at_ep_conc(zxyc_at_elev=zxyc_at_elev)
            output.append({
                'conc_ppm': conc_for_output_ppm,
                'elevation_m': elev,
                'max_dist_m': x,
                'area_m2': None,
            })

        self.max_dist_at_conc_results_df = pd.DataFrame(output)
    
    def get_x_at_ep_conc(self, zxyc_at_elev):
        x = None
        ep_conc = self.phast_dispersion.ep_conc
        for i in range(len(zxyc_at_elev)-1,-1,-1):
            row = zxyc_at_elev.iloc[i]
            conc = row['c']
            x = row['x']
            if conc < ep_conc:
                continue
            if conc >= ep_conc:
                break
        return x
    
    def get_max_conc_footprint_areas(self):
        if not hasattr(self.phast_dispersion, "haz_cat_conc_footprints_df"):
            return
        if len(self.phast_dispersion.haz_cat_conc_footprints_df) == 0:
            return
        haz = self.phast_dispersion.haz_cat_conc_footprints_df
        conseqs_all_cats = haz[haz[cd.KEYS_TARG_AND_TYPE_FLAM_OR_INHAL] == cd.HAZARD_TYPE_INHALATION]
        if len(conseqs_all_cats) == 0:
            conseqs_all_cats = haz[haz[cd.KEYS_TARG_AND_TYPE_FLAM_OR_INHAL] == cd.HAZARD_TYPE_FLASH_FIRE]
        cats = [cd.CAT_MODERATE, cd.CAT_SERIOUS]
        output = []
        for cat in cats:
            conseq_cat = conseqs_all_cats[conseqs_all_cats[cd.KEYS_TARG_AND_TYPE_CATEGORY] == cat]
            fp_dict_list = conseq_cat[cd.CONC_CALC_CONC_FOOTPRINT]
            for elev in [0, 6]:
                self.flattening.concUsed = np.inf
                area_m2 = self.flattening.calc_area(footprints_ser=fp_dict_list, cat=cat, elev_targ_m=elev)
                conc_ppm = self.flattening.concUsed * 1e6
                conc_ppm = helpers.float_value_rounded_to_x_sig_figs(conc_ppm, 4)
                output.append({
                    'conc_ppm': conc_ppm,
                    'elevation_m': elev,
                    'max_dist_m': None,
                    'area_m2': area_m2
                })
        self.max_conc_footprint_results_df = pd.DataFrame(output)
    
    def get_distances_to_thresholds_all_haz_types(self):

        mi = self.phast_dispersion.mi
        if mi.INHALATION:
            inhal_dists = self.get_distances_wrapper(inhalation=True)
            if inhal_dists is None:
                return
            self.distances_to_thresholds = dict(self.distances_to_thresholds , **inhal_dists)
        if mi.FLASH_FIRE:
            ff_dists = self.get_distances_wrapper(inhalation=False)
            if ff_dists is None:
                return
            self.distances_to_thresholds = dict(self.distances_to_thresholds , **ff_dists)

    def get_distances_wrapper(self, inhalation):
        locs = 'inhalation_locs'
        prefix = 'inhal'
        if not inhalation:
            locs = 'flam_loc_fracts'
            prefix = 'ff'
        distances_to_thresholds = {}
        thresholds = getattr(self.phast_dispersion.chems, locs)
        if inhalation:
            thresholds['10xloc_3'] = thresholds[3] * 10
        
        dists = self.get_distances_to_thresholds(thresholds)
        idx = 0
        if dists is None:
            return
        for k, v in dists.items():
            idx += 1
            distances_to_thresholds[f'{prefix}_{k}'] = v
        return distances_to_thresholds
        
    def get_distances_to_thresholds(self, thresholds):

        if not hasattr(self.phast_dispersion, "conc_profiles"):
            return
        if len(self.phast_dispersion.conc_profiles) == 0:
            return

        if len(self.flattening.conc_pfls) == 0:
            self.flattening.conc_pfls = self.phast_dispersion.conc_profiles

        dists = {}
        for k, v in thresholds.items():
            dist = self.flattening.updated_calc_max_dist_at_conc(v, min_ht_m=0, max_ht_m=6)
            title = k
            if isinstance(title, int):
                title = f'loc_{k}'
            dists[title] = dist
        
        return dists

    def get_overall_area_results(self):
        ca = self.ca
        conseq_list = ca.consequence_list
        impact_areas_m2 = {}
        for conseq in conseq_list:
            if conseq['category'] == cd.CAT_SERIOUS:
                impact_areas_m2[cd.CAT_SERIOUS] = conseq['impact_area_m2']
            if conseq['category'] == cd.CAT_MODERATE:
                impact_areas_m2[cd.CAT_MODERATE] = conseq['impact_area_m2']
        
        self.flattened_impact_areas_m2 = impact_areas_m2
            
