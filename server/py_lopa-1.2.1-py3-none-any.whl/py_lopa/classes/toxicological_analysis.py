import copy
import math
import numpy as np
import pandas as pd
from statistics import NormalDist

from py_lopa.calcs import helpers
from py_lopa.calcs.consts import Consts
from py_lopa.calcs.flattening import Flattening

cd = Consts().CONSEQUENCE_DATA

class Toxicological_Analysis:

    def __init__(self) -> None:
        self.cas_no = None
        self.volf = None
        self.cheminfo = None
        self.slot_n = None
        self.slot_ppm_n_min = None
        self.probit_a = None
        self.probit_b = None
        self.probit_n = None
        self.offsite_dist = None
        self.personnel_per_10k_m2 = None
        self.catastrophic_release = None
        self.estimate_mass_flow_kg_s = None

    def get_dose_and_probit_constants(self, cas_no, volf, cheminfo):
        self.cas_no = cas_no
        self.volf = volf
        self.cheminfo = cheminfo

        self.get_tox_info()

    def get_tox_info(self):

        tox_cols = Consts.COLUMNS_FOR_TOXICIOLOGICAL_DATA_IN_CHEMINFO

        for col in tox_cols:
            val = helpers.vlookup_value_x_in_pandas_dataframe_df_in_col_y_get_data_in_column_z(x = self.cas_no, df = self.cheminfo, y = 'cas_no', z = col)
            if pd.isna(val) or val == 0:
                val = None
            setattr(self, col, val)

    def building_infiltration_analysis(self, conc_outside, ach_forced = 4, ach_natural = 1, max_time_to_cutoff_airhandler_sec = 3600):

        max_time_to_cutoff_airhandler_min = max_time_to_cutoff_airhandler_sec / 60

        max_ach = Consts.MAX_ACH
        ach_forced = min(ach_forced, max_ach)
        ach_natural = min(ach_natural, max_ach)
        max_conc_indoor = -np.inf
        max_time = Consts.MAX_MINUTES_FOR_EVALUATION
        k_forced = ach_forced / 60
        k_natural = ach_natural / 60

        conc_outside *= 1000000 # convert to ppm
        conc_outside *= self.volf
        
        # structure by column
        # 0 - time (min)
        # 1 - outdoor conc (ppm)
        # 2 - indoor conc (ppm)
        # 3 - indoor conc^(slot_n)
        # 4 - dose for slot (integrated 3rd col)
        # 5 - indoor conc^(probit_n)
        # 6 - dose for probit (integrated 5th col)
        # 7 - Y-score
        # 8 - probit

        arr = np.zeros((max_time, 9))
        arr[:,0] = np.arange(arr.shape[0])
        arr[:,1] = conc_outside
        
        for t in range(arr.shape[0]):
            k = k_forced
            t_model = t
            if t > max_time_to_cutoff_airhandler_min:
                k = k_natural
                t_model = t - max_time_to_cutoff_airhandler_min
            conc_indoor = conc_outside - conc_outside * math.exp(-k*t_model)
            arr[t, 2] = conc_indoor
            max_conc_indoor = max(max_conc_indoor, conc_indoor)
        
        arr = self.dose_and_probit_analysis(arr)
        
        df = pd.DataFrame(arr, columns = ['time_min',
            'outdoor_conc_ppm',
            'indoor_conc_ppm',
            'indoor_conc_ppm^(slot_n)',
            'slot_dose_ppm_n_min',
            'indoor_conc_ppm^(probit_n)',
            'probit_dose_ppm_n_min',
            'y_score',
            'probablity_of_severe_injury'
        ])
        
        slot_above_threshold = False
        try:
            slot_above_threshold = (arr[-1,4] >= self.slot_ppm_n_min)
        except:
            pass

        ans = {
            'conc_and_tox_profile': df,
            'max_conc_indoor_volf': max_conc_indoor / 1000000,
            'max_slot_dose':  arr[-1, 4],
            'max_probability_of_severe_injury': arr[-1, 8],
            'slot_dose_above_threshold':slot_above_threshold,
            'probability_of_severe_injury_above_threshold': arr[-1, 8] >= Consts.THRESHOLD_PROBABILITY_SEVERE_INJURY
        }

        return ans
    
    def on_site_dose_probit_analysis(self, conc_pfls = None):

        # assume individual flees at 5 mph
        # as fleeing, they ingest the maximum possible dose.  this comes from the max conc at dist object

        # this is strictly for debugging.  if I save a pickle of this class, I will have the conc profiles stored.
        # it won't be needed as a parameter here.

        if conc_pfls is not None:
            self.conc_pfls = conc_pfls

        veloc_mph = Consts.FLEEING_VELOCITY_MPH
        veloc_meters_per_minute = veloc_mph * 5280 / 3.28084 / 60
        flat_proj = Flattening(conc_pfls=conc_pfls)

        min_ht_m = 0
        max_ht_m = Consts.ELEVATION_RANGE_FOR_CONC_EVAL_M

        conc_vs_dist = flat_proj.get_zxyc_array_from_conc_pfls_bet_min_and_max_elevation(min_ht_m=min_ht_m, max_ht_m=max_ht_m)
        pws_dw_dist_vect = conc_vs_dist[:,1]

        # points from zero to the max dist for on-site analysis.  the assumption here is that the individual will, by the time they reach the gate or fence, 
        # determine an alternate path out of the cloud.
        # the points are spaced by the distance in meters that an individual could make in one tenth of a minute (6 sec) going 5 mph.

        num_points = max(2, int(self.offsite_dist))

        dists_for_probit = np.linspace(0, self.offsite_dist, num_points)
        
        arr = []

        for i in range(len(dists_for_probit)):
            # x is the point at which the individual will be at the start of each minute while fleeing
            
            x = dists_for_probit[i]
            curr_time_min = x / veloc_meters_per_minute
            # finding the closest point generated from pws to the points along the path of the fleeing individual, spaced by the distance run at 5 mph each min
            diff = np.absolute(pws_dw_dist_vect - x)
            idx_min = np.argmin(diff)
            pws_dist = pws_dw_dist_vect[idx_min]

            # using the existing methods to find the maximum possible concentration at elevations between 0 and 6 meters above ground.
            max_conc_near_dist = flat_proj.calc_max_conc_at_dist(dist_m=pws_dist, min_ht_m=min_ht_m, max_ht_m=max_ht_m, zxyc=conc_vs_dist)
            max_conc_near_dist *= 1e6
            max_conc_near_dist *= self.volf

            # lots of zeros to fill out the needed columns.

            arr.append([curr_time_min, x, max_conc_near_dist, 0, 0, 0, 0, 0, 0])

        # for each measured distance, determine the total dose / prob sev inj of an individual starting to flee from there.
        
        arr = np.array(arr)
        for i in range(len(arr)):
            arr_for_analysis = self.dose_and_probit_analysis(arr[i:])
            final_row = arr_for_analysis[-1]
            final_slot_dose = final_row[4]
            final_probability = final_row[-1]
            arr[i, 4] = final_slot_dose
            arr[i, -1] = final_probability

        df = pd.DataFrame(arr, columns = ['time_min',
            'dw_dist_m',
            'conc_ppm',
            'conc_ppm^(slot_n)',
            'slot_dose_ppm_n_min',
            'conc_ppm^(probit_n)',
            'probit_dose_ppm_n_min',
            'y_score',
            'probablity_of_severe_injury'
        ])

        ans = {
            'conc_and_tox_profile': df,
        }

        return ans

    def dose_and_probit_analysis(self, arr):

        # assumption - 1st col is time.  last col is concentration to analyze.  conc can be either indoor or outdoor, depending on the analysis

        arr_local = np.copy(arr)

        # structure by column
        # 0 - time (min)
        # 1 - outdoor conc (ppm) for bldg analysis or dw dist for onsite
        # 2 - indoor conc (ppm) for bldg analysis or outdoor conc for onsite.  this is the column that will be analyzed for dose-response.
        # 3 - conc^(slot_n)
        # 4 - dose for slot (integrated 3rd col)
        # 5 - conc^(probit_n)
        # 6 - dose for probit (integrated 5th col)
        # 7 - Y-score
        # 8 - probit

        slot_n = 0
        probit_a = 0
        probit_b = 0
        probit_n = 0

        if self.slot_n is not None:
            slot_n = self.slot_n
        
        if self.probit_a is not None:
            probit_a = self.probit_a
            probit_b = self.probit_b
            probit_n = self.probit_n

        for t in range(arr_local.shape[0]):
            if slot_n != 0:
                arr_local[t, 3] = arr_local[t, 2] ** slot_n
                if t > 0:
                    # trapezoid rule for inegration
                    arr_local[t, 4] = arr_local[t-1, 4] + (arr_local[t, 0] - arr_local[t-1, 0]) * 0.5 * (arr_local[t-1, 3] + arr_local[t, 3])
            if probit_n != 0:
                arr_local[t,5] = arr_local[t, 2] ** probit_n
                if t > 0:
                    arr_local[t, 6] = arr_local[t-1, 6] + (arr_local[t, 0] - arr_local[t-1, 0]) * 0.5 * (arr_local[t-1, 5] + arr_local[t, 5])
                    try:
                        arr_local[t, 7] = (probit_a - 5) + probit_b * math.log(arr_local[t, 6])
                        arr_local[t, 8] = NormalDist().cdf(arr_local[t, 7])
                    except:
                        pass

        return arr_local

    def get_impact_area_from_dw_dispersion(self):
        pass