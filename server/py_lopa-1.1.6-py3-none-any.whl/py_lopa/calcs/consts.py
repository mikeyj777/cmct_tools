import numpy as np
from enum import IntEnum, Enum

class Consts:
    WIND_SPEED_DEFAULT_MS = 1.5
    MAX_ACH = 10
    TOLERANCE_PERCENT_GENERAL = 0.2
    TOLERABLE_RELIEF_RATE_DEVIATION_FROM_VESSEL_CALCS = 0.05
    THRESHOLD_MIN_PCT_CHANGE = 0.01
    R_PA_M3_KMOL_DEGK = 8314.47
    ELEVATION_RANGE_FOR_CONC_EVAL_M = 6
    MIN_DIST_BET_ELEVS_M = 2
    MATERIAL_NAME = 'Releasing Stream'
    BLANK_MATERIAL_ENTRY_NAME = 'ComponentName'
    TOLERANCE_CONSEQUENCE_RESULT_PCT = 0.2
    MAX_MINUTES_FOR_EVALUATION = 60
    TOLERANCE_DEGREES_C_FROM_RELIEF_PHASE = 5
    LB_PER_KG = 2.20462
    GAL_PER_M3 = 264.172
    TOLERANCE_RATIO_SOLVED_DIAM_VS_USER_ENTERED_DIAM = 0.2
    RELEASE_DURATIONS_TO_MODEL_SEC = [
        15*60,
        30*60,
        45*60,
        60*60
    ]
    CATASTROPHIC_RELEASE_DURATIONS_TO_MODEL_SEC = [10]
    INHALATION = 'inhalation'
    FLASH_FIRE = 'flash_fire'
    VCE = 'vapor_cloud_explosion'
    PV_BURST = 'pv_burst'

    AVERAGING_TIME_SEC = {
        FLASH_FIRE: 18.75,
        INHALATION: 600
    }
    ONSITE_EVAL_CONC_FOOTPRINT_ELEVATIONS = [0, ELEVATION_RANGE_FOR_CONC_EVAL_M / 2, ELEVATION_RANGE_FOR_CONC_EVAL_M]
    WIND_DIRECTIONS_RADIANS_FROM_NORTH_UP_FOR_PLUME_PLOTTING_IN_KML = np.linspace(0, 2*np.pi, 16, endpoint=False)
    MAX_HOLE_SIZE_IN_PCT_OF_VESSEL_DIAM = 0.8
    L_BY_D = 1 # ratio of vessel length to vessel diameter
    POOL_AREA_DEFAULT_M2 = np.inf
    CUSTOM_CHEM_NAME_APPEND = ' EMN Chem'
    BAD_CHARS_FOR_FILE_NAME = [
        ':',
        '.',
        '<',
        '>',
        '"',
        ':',
        chr(92),
        '|',
        '?',
        '*',
        ' ',
    ]

    COLUMNS_FOR_TOXICIOLOGICAL_DATA_IN_CHEMINFO = [
        'slot_ppm_n_min',
        'slot_n',
        'probit_a',
        'probit_b',
        'probit_n'
    ]
    FLEEING_VELOCITY_MPH = 5
    THRESHOLD_PROBABILITY_SEVERE_INJURY = 0.01
    

    def __init__(self):
        self.RELEASE_STREAM_ATTRIBS = Release_Stream_Attribute_Names
        self.CONSEQUENCE_DATA = Consequence_Data()
        self.RELIEF_PHASE = Relief_Phase


class Release_Stream_Attribute_Names:
    CAS_NO = 'cas_no'
    CHEM_NAME = 'chem_name'
    MOLE_FRACT = 'mole_fraction'
    MW = 'mw'
    VAP_MOL_FRACT = 'vapor_mole_fraction'
    PHAST_ID = 'phast_id'
    MATERIAL_COMPONENT_ID = 'mat_comp_id'

class Consequence_Data:

    PHASE_TWO_PHASE = 'two_phase'
    PHASE_LET_MODEL_DECIDE = 'let_model_decide'
    PHASE_LIQUID = 'liquid'
    PHASE_VAPOR = 'vapor'

    OUTPUT_DISPERSION_OBJECT = 'dispersion_object'
    OUTPUT_DISPERSION_KML_BYTESTR = 'output_dispersion_kml_bytestr'

    OUTPUT_DICT_RELEASE_DURATION_SEC = 'release_duration_sec'
    OUTPUT_DICT_MASS_RELEASED_KG = 'mass_released_kg'
    OUTPUT_DICT_HAZARD_RECS = 'hazard_recs'
    OUTPUT_CONCENTRATION_USED_PPM_STR = 'conc_used_ppm_str'
    OUTPUT_DICT_RELEASE_DURATION_MIN = 'release_duration_min'
    
    DOSE_PROBIT_DATA_FOR_KML_ZXY = 'dose_probit_data_for_kml_zxy'

    ALTITUDE_WD_LON_LAT = 'wind_direction_alt_long_lat'
    RADIAL_CIRCLE_DICT = 'radial_circle_dict'
    MIN_X = 'min_x'
    MAX_X = 'max_x'
    OUTER_BOUNDS = 'outer_bounds'
    INNER_BOUNDS = 'inner_bounds'
    ALTITUDE = 'altitude'
    LONG_LAT = 'long_lat'
    WIND_DIRECTION = 'wind_direction'

    CAT_TITLE = 'category'
    CAT_MINOR = 'minor'
    CAT_MODERATE = 'moderate'
    CAT_SERIOUS = 'serious'
    CAT_CRITICAL = 'critical'
    CAT_CATASTROPHIC = 'catastrophic'

    OCCUPANCY = 'occupancy'
    RESULTS = 'results'
    REQUIRED_AREA_M2 = 'required_area_m2'
    IMPACT_AREA_M2 = 'impact_area_m2'
    IMPACT_DISTANCE_M = 'impact_distance_m'
    PROBABILITY_OF_EXPOSURE = 'probability_of_exposure'
    CAT_SCORE = 'cat_score'
    CAT_PLUS_POE = 'cat_plus_poe'
    LOG_POE = 'log_poe'

    JSON_NULL = 'null'
    
    OCC_UNOCCUPIED = 0
    OCC_LOW = 1
    OCC_MEDIUM = 4
    OCC_HIGH = 32

    OCC_NIGHT = 'night_occupancy'

    CLASS_TITLE = 'class'
    CLASS_ONSITE = 'onsite'
    CLASS_BLDG = 'building'
    CLASS_OFFSITE = 'offsite'

    CONC_VOLF_TITLE = 'conc_volf'
    WORST_CASE_CHEM_INDEX = 'index'

    RELEASE_TIER_DESIGNATION = 'release_tier'

    KEYS_TARG_AND_TYPE_FLAM_OR_INHAL = 'flash fire or inhalation'
    KEYS_TARG_AND_TYPE_CLASS = 'class'
    KEYS_TARG_AND_TYPE_CATEGORY = 'category'
    KEYS_TARG_AND_TYPE_DIST_M = 'dist_m'
    KEYS_TARG_AND_TYPE_CONC_VOLF = CONC_VOLF_TITLE
    KEYS_TARG_AND_TYPE_BLDG_DIST_M = 'bldg_dist_m'
    KEYS_TARG_AND_TYPE_BLDG_HEIGHT_M = 'bldg_height_m'
    KEYS_TARG_AND_TYPE_BLDG_NUM = 'bldg_number'
    KEYS_TARG_AND_TYPE_BLDG_ACH = 'bldg_ach'
    KEYS_TARG_AND_TYPE_BLDG_HVAC_SHUTOFF_SEC = 'bldg_hvac_shutoff_sec'
    
    KEYS_TARG_AND_TYPE_RESULTS_DIST_M = 'results_dist_m'
    KEYS_TARG_AND_TYPE_RESULTS_CONC_VOLF = 'results_conc_volf'
    KEYS_TARG_AND_TYPE_RESULTS_QUALIFIED_RESULT = 'qualified_result'

    KEYS_BLDG_UNOCCUPIED = 'unoccupied'
    KEYS_BLDG_LOW_OCC = 'low'
    KEYS_BLDG_MED_OCC = 'med'
    KEYS_BLDG_HIGH_OCC = 'high'

    KEYS_BLDG_DISTS_M = 'bldg_dists_m'
    KEYS_BLDG_HEIGHTS_M = 'bldg_heights_m'
    KEYS_BLDG_NUMS = 'bldg_nums'
    KEYS_BLDG_ACH = 'bldg_ach'
    KEYS_BLDG_HVAC_SHUTOFF_SEC = 'bldg_hvac_shutoff_sec'

    KEYS_BLDG_DATA = 'bldg_data'

    KEYS_MAX_DIST_M = 'max_dist_m'
    KEYS_MIN_DIST_M = 'min_dist_m'
    KEYS_MAX_HEIGHT_M = 'max_height_m'

    KEYS_DIST_TO_OFFSITE_M = 'dist_to_offsite_m'
    KEYS_ONSITE_POP_DENSITY_NUM_PPL_PER_10K_M2 = 'on-site pop density'

    CONC_CALC_ELEV_M = 'elev_m'
    CONC_CALC_CONC_PFL_CALC = 'conc_pfl_calc'
    CONC_CALC_CONC_FOOTPRINT = 'conc_footprint'

    HAZARD_TYPE_INHALATION = Consts.INHALATION
    HAZARD_TYPE_FLASH_FIRE = Consts.FLASH_FIRE
    HAZARD_TYPE_VCE = Consts.VCE
    HAZARD_TYPE_PV_BURST = Consts.PV_BURST

    AREA_M2 = 'area_m2'
    DISTANCE_TO_LFL_M = 'distance_to_lfl_m'

    WEATHER_CONDITION = 'weather_condition'

    NITROGEN = 'NITROGEN'
    AIR = 'AIR'
    WATER = 'WATER'

    def __init__(self):
        self.CAT_ALL_CATEGORIES = [
            self.CAT_MINOR,
            self.CAT_MODERATE,
            self.CAT_SERIOUS,
            self.CAT_CRITICAL,
            self.CAT_CATASTROPHIC
        ]

        self.CAT_HIGHER_LEVEL_IMPACT = self.CAT_ALL_CATEGORIES[-3:]

        self.ALL_OCCUPANCY_LEVELS_LIST = [
            self.OCC_LOW, 
            self.OCC_MEDIUM, 
            self.OCC_HIGH
        ]

        self.ONSITE_IMPACTED_PERSONNEL = {
            self.CAT_MINOR: self.OCC_LOW,
            self.CAT_MODERATE: self.OCC_LOW,
            self.CAT_SERIOUS: self.OCC_LOW,
            self.CAT_CRITICAL: self.OCC_MEDIUM,
            self.CAT_CATASTROPHIC: self.OCC_HIGH
        }

        self.CLASS_ALL_CLASSES = [
            self.CLASS_ONSITE,
            self.CLASS_BLDG,
            self.CLASS_OFFSITE
        ]

        self.KEYS_BLDG_ALL_OCC = [
            self.KEYS_BLDG_LOW_OCC,
            self.KEYS_BLDG_MED_OCC,
            self.KEYS_BLDG_HIGH_OCC
        ]

        self.HAZARD_ALL_TYPES = [
            self.HAZARD_TYPE_INHALATION,
            self.HAZARD_TYPE_FLASH_FIRE,
            self.HAZARD_TYPE_VCE
        ]

        self.JSON_OUTPUT_ATTRIBS = [
            'hazard_type',
            'consequence_class',
            'consequence_category',
            'consequence_target',
            'consequence_result',
            'release_duration_sec',
            'hazard_recs'
        ]

        self.WX_ALL_TYPES = [
            Wx_Enum.DAY,
            Wx_Enum.NIGHT
        ]

        self.WX_WORST_CASE = Wx_Enum.NIGHT
        self.WX_DAY = Wx_Enum.DAY

        self.OCC_NUMBER_TO_STRING_DICT = {
            self.OCC_UNOCCUPIED: self.KEYS_BLDG_UNOCCUPIED,
            self.OCC_LOW: self.KEYS_BLDG_LOW_OCC,
            self.OCC_MEDIUM: self.KEYS_BLDG_MED_OCC,
            self.OCC_HIGH: self.KEYS_BLDG_HIGH_OCC
        }

        self.PROBABILITY_OF_EXPOSURE_MAXIMUM_CLOSED_ENDED = {
            0.01: '-2',
            0.032: '-1 and 1 partial order',
            0.1: '-1',
            0.32: '1 partial order',
            np.inf: '0'
        }

        self.PROBABILITY_OF_EXPOSURE_MAXIMUM_CLOSED_ENDED_FLOAT_VALUES = {
            0.01: -2,
            0.032: -1.5,
            0.1: -1,
            0.32: -0.5,
            np.inf: 0
        }

        self.NITROGEN_CAS_NO = '7727-37-9'
        self.AIR_CAS_NO = '132259-10-0'
        self.WATER_CAS_NO = '7732-18-5'

        self.CAS_NOS_OF_CONCERN = {
            self.NITROGEN: self.NITROGEN_CAS_NO,
            self.AIR: self.AIR_CAS_NO,
            self.WATER: self.WATER_CAS_NO,
        }

class Relief_Phase(IntEnum):
    VAPOR = 0
    TWO_PHASE = 1
    LIQUID = 2
    LET_MODEL_DECIDE = 3

class Wx_Enum:
    NIGHT = 'night'
    DAY = 'day'

