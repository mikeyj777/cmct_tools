import math
import copy
import numpy as np
import pandas as pd
from datetime import datetime as dt

from py_lopa.calcs import helpers
from py_lopa.calcs.consts import Consts

cd = Consts().CONSEQUENCE_DATA

class Flattening:
    def __init__(self, haz_cat_conc_footprints_df={}, analysis_df={}, conc_pfls = {}):
        self.haz_cat_conc_footprints_df = haz_cat_conc_footprints_df
        self.analysis_df = analysis_df
        self.conc_pfls = conc_pfls
        self.concUsed = -1e6
        self.prev_area = 0
        self.areas_m2_df = {}
        self.zxys_list = []
        self.zxys_df = pd.DataFrame()
    
    def get_areas(self):
        
        if len(self.haz_cat_conc_footprints_df) == 0:
            return None

        # calculate areas of impact for flash fire and inhalation associated with higher-level consequences
        df = self.haz_cat_conc_footprints_df
        areas_m2 = []
        for haz_type in cd.HAZARD_ALL_TYPES:
            curr_haz_df = df[df[cd.KEYS_TARG_AND_TYPE_FLAM_OR_INHAL] == haz_type]
            if len(curr_haz_df) == 0:
                continue
            for cat in cd.CAT_ALL_CATEGORIES:
                curr_haz_cat = curr_haz_df[curr_haz_df[cd.CAT_TITLE] == cat]
                curr_haz_cat_footprints_ser = curr_haz_cat[cd.CONC_CALC_CONC_FOOTPRINT]
                curr_area_m2 = self.calc_area(curr_haz_cat_footprints_ser, cat=cat)
                areas_m2.append({cd.KEYS_TARG_AND_TYPE_FLAM_OR_INHAL: haz_type, cd.CAT_TITLE: cat, cd.AREA_M2:curr_area_m2})
        
        self.areas_m2_df = pd.DataFrame(areas_m2)

        if len(self.zxys_list) > 0:
            self.zxys_df = pd.DataFrame(self.zxys_list)

        return self.areas_m2_df
    
    def calc_area(self, footprints_ser, zxy = [], cat = None, elev_targ_m = None):

        if len(footprints_ser) == 0:
            return 0

        fp_dict_list = footprints_ser.values[0]
        
        if len(fp_dict_list) == 0:
            return 0

        # need a less cleugy way to check if this concentration has already been processed for 
        # a previous consequence category.
        concUsed = fp_dict_list[0][cd.CONC_CALC_CONC_FOOTPRINT].conc_used
        
        if concUsed == self.concUsed:
            return self.prev_area

        self.concUsed = concUsed

        zxy = []
        for fp_dict in fp_dict_list:
            if elev_targ_m is not None:
                if fp_dict[cd.CONC_CALC_ELEV_M] != elev_targ_m:
                    continue
            fps = fp_dict[cd.CONC_CALC_CONC_FOOTPRINT]
            cp_s = fps.contour_points
            for cp in cp_s:
                zxy.append([cp.z, cp.x, cp.y])
        
        if len(zxy) == 0:
            self.prev_area = 0
            return 0

        zxy_np = np.asarray(zxy)
        zxy_np_pos = zxy_np[zxy_np[:,2] > 0]
        area = self.get_zxy_area(zxy_np_pos)

        self.prev_area = area
        if cat is not None:
            self.zxys_list.append({
                cd.CAT_TITLE: cat,
                'conc_used': concUsed,
                'zxy': zxy
            })

        return area

    def get_zxy_area(self, zxy, del_x = 0.1):

        # take all z, x, y coords along the footprint contour.
        # (really don't need the 'z' coords, but leaving them in for diagnostics)
        # sort by x
        # all y's <= 0 have been removed.  The cloud 'should' be symmetric along the x axis in the xy-plane.  
        # any zero-width segments do not contribute to area.
        # iterate across zxy from lowest x value to highest.
        # approximate total area with area of trapezoid segments of "del_x" width.
        # along each "del_x" segment, find the greatest width.  set this width equal to "widest_y"
        # the other trapezoid "y" width is "widest_y_prev", captured in the previous segment.
        # use the trapezoid rule of integration to estimate accumulated area

        zxy = zxy[zxy[:,1].argsort()]
        tot_area = 0
        x0 = zxy[0,1]
        tot_area = 0
        widest_y = zxy[0,2]
        widest_y_prev = widest_y
        for i in range(1, zxy.shape[0]):
            widest_y = max(widest_y, zxy[i,2])

            if zxy[i,1] - x0 > del_x:
                tot_area += (widest_y + widest_y_prev) * 0.5 * (zxy[i,1] - x0)
                widest_y_prev = widest_y
                widest_y = zxy[i,2]
                x0 = zxy[i,1]
                continue
        
        # add any remaining area in the trailing segment if less than a "del_x" in width
        if x0 != zxy[zxy.shape[0]-1,1] and x0 + del_x > zxy[zxy.shape[0]-1,1]:
            tot_area += (widest_y + widest_y_prev) * 0.5 * (zxy[zxy.shape[0]-1,1] - x0)
        
        tot_area *= 2

        return tot_area
    
    def get_zxyc_array_from_conc_pfls_bet_min_and_max_elevation(self, min_ht_m,  max_ht_m):
        
        cp_s = self.conc_pfls

        zxyc = []
        for cp in cp_s:
            elev_m = cp[cd.CONC_CALC_ELEV_M]
            if elev_m >= min_ht_m and elev_m <= max_ht_m:
                conc_pfl = cp[cd.CONC_CALC_CONC_PFL_CALC]
                cr_s = conc_pfl.concentration_records
                if cr_s is None:
                    continue
                for cr in cr_s:
                    pos = cr.position
                    row = [pos.z, pos.x, pos.y, cr.concentration]
                    zxyc.append(row)
        
        zxyc = np.array(zxyc)

        # zxyc = np.stack(zxyc)

        return zxyc

    def calc_min_dist_at_conc(self, targ_conc_volf, min_ht_m, max_ht_m, zxyc = []):
        '''
        
        used to calculate distance to flammable extent 
        
        '''
        if len(zxyc) == 0:
            zxyc = self.get_zxyc_array_from_conc_pfls_bet_min_and_max_elevation(min_ht_m, max_ht_m)
        if len(zxyc) == 0:
            return 0
        zxyc = zxyc[zxyc[:,1].argsort()]
        zxyc_greater_than_or_equal_targ_conc = False
        for i in range(zxyc.shape[0]):
            if zxyc[i,3] >= targ_conc_volf:
                zxyc_greater_than_or_equal_targ_conc = True
                break
        ans = pd.NA
        if zxyc_greater_than_or_equal_targ_conc:
            ans = zxyc[i, 1]
            ans = abs(ans)
        
        return ans

    # to be implemented in future after pws 4 and mc changes.
    def updated_calc_max_dist_at_conc(self, targ_conc_volf, min_ht_m, max_ht_m, zxyc = []):
        if len(zxyc) == 0:
            zxyc = self.get_zxyc_array_from_conc_pfls_bet_min_and_max_elevation(min_ht_m, max_ht_m)
        if len(zxyc) == 0:
            return 0
        zxyc_greater_than_or_equal_targ_conc = False
        zxyc = zxyc[zxyc[:,1].argsort()]
        for i in range(zxyc.shape[0]-1,-1,-1):
            if zxyc[i,3] >= targ_conc_volf:
                zxyc_greater_than_or_equal_targ_conc = True
                break
        ans = pd.NA
        if zxyc_greater_than_or_equal_targ_conc:
            ans = zxyc[i, 1]
            ans = abs(ans)
        
        return ans

    def calc_max_dist_at_conc(self, targ_conc_volf, min_ht_m, max_ht_m, zxyc = []):
        if len(zxyc) == 0:
            zxyc = self.get_zxyc_array_from_conc_pfls_bet_min_and_max_elevation(min_ht_m, max_ht_m)
        if len(zxyc) == 0:
            return 0
        zxyc = zxyc[zxyc[:,1].argsort()]
        zxyc_conc_diff = copy.deepcopy(zxyc)
        zxyc_conc_diff[:,3] = np.absolute(zxyc_conc_diff[:,3] - targ_conc_volf)
        min_idx = np.inf
        min_val = np.inf
        zxyc_greater_than_or_equal_targ_conc = False
        for i in range(zxyc_conc_diff.shape[0]-1,-1,-1):
            if zxyc[i,3] >= targ_conc_volf:
                zxyc_greater_than_or_equal_targ_conc = True
            conc_diff = zxyc_conc_diff[i, 3]
            if conc_diff == 0:
                min_val = conc_diff
                min_idx = i
                break
            if conc_diff < min_val:
                min_val = conc_diff
                min_idx = i
        ans = pd.NA
        if zxyc_greater_than_or_equal_targ_conc:
            ans = zxyc[min_idx, 1]
            ans = abs(ans)
        
        return ans

    def calc_max_conc_at_dist(self, dist_m, min_ht_m, max_ht_m, zxyc = []):
        if len(zxyc) == 0:
            zxyc = self.get_zxyc_array_from_conc_pfls_bet_min_and_max_elevation(min_ht_m, max_ht_m)
        
        if len(zxyc) == 0:
            return 0

        zxyc = zxyc[zxyc[:,1].argsort()]

        # max x-distance range to analyze concentration is 10 meters.
        
        dist_tol = min(dist_m * Consts.TOLERANCE_PERCENT_GENERAL, 10)
        min_dist = dist_m - dist_tol
        max_dist = dist_m + dist_tol
        max_conc = 0

        for i in range(zxyc.shape[0]):
            curr_point = zxyc[i,1]
            curr_conc = zxyc[i, 3]
            curr_diff = abs(zxyc[i,1] - dist_m)
            if curr_point >= min_dist and curr_point <= max_dist:
                if curr_conc > max_conc:
                    max_conc = curr_conc
        
        if max_conc > 0:
            return max_conc
        
        df = pd.DataFrame(zxyc, columns=['z', 'x', 'y', 'c'])
        grouped = df.groupby('z')
        concs = []
        for z, xyc in grouped:
            conc = self.bracket_values_interpolate_and_return_0_if_out_of_bounds(value=dist_m, df=xyc, colname='x', out_col='c')
            if conc is not None:
                concs.append(conc)

        if len(concs) == 0:
            return 0
 
        max_conc = max(concs)
        
        return max_conc
    
    def bracket_values_interpolate_and_return_0_if_out_of_bounds(self, value, df, colname, out_col):
        if len(df) == 0:
            return 0

        # min dist is the distance above which the tolerance consequence result will be applied.
        # above min dist, if the concentration is measured at a distance outside of the tolerance
        # the method will return 0 for conc outside building.
        # for a building at a distance less than or equal to the min dist, the closest 
        # concentration to the building will be used.

        # 15 meters is chosen such that, even a negative x value can be no greater than 
        # 27 meters from the building and still qualify using this methdology.
        # 27 meters is good because it's less than 30 meters.
        # The 30 meter max deviation which is arbitrary, but a reasonable value for consequence assessment.

        min_dist_for_eval_m = 15
        tol = Consts.TOLERANCE_CONSEQUENCE_RESULT_PCT

        valid_distance = max(min_dist_for_eval_m, tol * value)

        xc_out = []
        exactmatch = df[df[colname] == value]
        if len(exactmatch) > 1:
            concs = exactmatch[out_col].values
            return max(concs)
        if len(exactmatch) == 1:
            c = helpers.get_data_from_pandas_series_element(exactmatch[out_col])
            return c
        if exactmatch.empty:
            lowerneighbour = df[df[colname] < value]
            upperneighbour = df[df[colname] > value]

            x0 = helpers.get_data_from_pandas_series_element(lowerneighbour[colname].tail(1))
            c0 = helpers.get_data_from_pandas_series_element(lowerneighbour[out_col].tail(1))
            x1 = helpers.get_data_from_pandas_series_element(upperneighbour[colname].head(1))
            c1 = helpers.get_data_from_pandas_series_element(upperneighbour[out_col].head(1))

            # lower_end_qualifies = False
            # higher_end_qualifies = False

            # min_dist = value - valid_distance
            # max_dist = value + valid_distance

            # if x0 is not None:
            #     if x0 >= min_dist:
            #         lower_end_qualifies = True
            
            # if x1 is not None:
            #     if x1 <= max_dist:
            #         higher_end_qualifies = True
                    
            # if not(higher_end_qualifies or lower_end_qualifies):
            #     return 0

            xc_out = []
            for x,c in [[x0, c0], [x1, c1]]:
                if x is not None and c is not None:
                    xc_out.append([x,c])
        
        if len(xc_out) == 0:
            return 0
        
        if len(xc_out) == 1:
            x = xc_out[0][0]
            c = xc_out[0][1]
            val_test = value


            # when building is close to the release and the closest measured point is outside
            # of the tolerable bound, return conc equal at closest measured point
            if abs(value) <= min_dist_for_eval_m and abs(x) <= min_dist_for_eval_m * (1-tol):
                return c
            if val_test == 0:
                val_test = 0.01
            dev = abs((val_test - x) / val_test)
            if dev > tol:
                return 0
            return c
        
        if len(xc_out) == 2:
            x0 = xc_out[0][0]
            x1 = xc_out[1][0]
            c0 = xc_out[0][1]
            c1 = xc_out[1][1]

            if x1 == x0:
                return max(c1, c0)
            
            m = (c1-c0) / (x1-x0)
            b = c0 - m * x0

            c = m * value + b

            return max(0, c)
    
        return 0
