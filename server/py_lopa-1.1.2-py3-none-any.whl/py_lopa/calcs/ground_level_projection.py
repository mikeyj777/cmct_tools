import math
import copy
import numpy as np
import pandas as pd
from datetime import datetime as dt

from py_lopa.calcs import helpers
from py_lopa.calcs.consts import Consts

cd = Consts().CONSEQUENCE_DATA

class Ground_Level_Projection:
    def __init__(self, haz_cat_conc_footprints_df, analysis_df):
        self.haz_cat_conc_footprints_df = haz_cat_conc_footprints_df
        self.analysis_df = analysis_df
        self.concUsed = -1e6
        self.prev_area = -1e6
        self.areas_m2_df = {}
    
    def get_areas(self):
        
        if len(self.haz_cat_conc_footprints_df) == 0:
            return None

        # calculate areas of impact for flash fire and inhalation associated with higher-level consequences
        df = self.haz_cat_conc_footprints_df
        areas_m2 = []
        for haz_type in cd.HAZARD_ALL_TYPES:
            curr_haz_df = df[df[cd.KEYS_TARG_AND_TYPE_FLAM_OR_INHAL] == haz_type]
            for cat in cd.CAT_HIGHER_LEVEL_IMPACT:
                curr_haz_cat = curr_haz_df[curr_haz_df[cd.CAT_TITLE] == cat]
                curr_haz_cat_footprints_ser = curr_haz_cat[cd.CONC_CALC_CONC_FOOTPRINT]
                curr_area_m2 = self.calc_area(curr_haz_cat_footprints_ser)
                areas_m2.append({cd.KEYS_TARG_AND_TYPE_FLAM_OR_INHAL: haz_type, cd.CAT_TITLE: cat, cd.AREA_M2:curr_area_m2})
        
        self.areas_m2_df = pd.DataFrame(areas_m2)

        return self.areas_m2_df

    def calc_area(self, footprints_ser):
        fp_dict_list = footprints_ser.values[0]
        
        # need a less cleugy way to check if this concentration has already been processed for 
        # a previous consequence category.
        concUsed = fp_dict_list[0][cd.CONC_CALC_CONC_FOOTPRINT].concUsed
        
        if concUsed == self.concUsed:
            return self.prev_area

        self.concUsed = concUsed

        zxy = []
        for fp_dict in fp_dict_list:
            fps = fp_dict[cd.CONC_CALC_CONC_FOOTPRINT]
            cp_s = fps.contourPoints
            for cp in cp_s:
                zxy.append([cp.z, cp.x, cp.y])
        
        
        zxy_np = np.asarray(zxy)
        zxy_np_pos = zxy_np[zxy_np[:,2] > 0]
        area = self.get_zxy_area(zxy_np_pos)

        return area


    def get_zxy_area(self, zxy, del_x = 0.1):

        # take all z, x, y coords along the footprint contour.
        # (really don't need the 'z' coords, but leaving them in for diagnostics)
        # sort by x
        # all y's <= 0 have been removed.  The cloud 'should' be symmetric along the x axis in the xy-plane.  
        # any zero-width segments do not contribute to area.
        # iterate across zxy from lowest x value to highest.
        # approximate total area with area of trapezoid segments of "del_x" width.
        # along each "del_x" segment, find the greatest width.  set this width equal to "widest_y"
        # the other trapezoid "y" width is "widest_y_prev", captured in the previous segment.
        # use the trapezoid rule of integration to estimate accumulated area

        zxy = zxy[zxy[:,1].argsort()]
        tot_area = 0
        x0 = zxy[0,1]
        tot_area = 0
        widest_y = zxy[0,2]
        widest_y_prev = widest_y
        for i in range(1, zxy.shape[0]):
            widest_y = max(widest_y, zxy[i,2])

            if zxy[i,1] - x0 > del_x:
                tot_area += (widest_y + widest_y_prev) * 0.5 * (zxy[i,1] - x0)
                widest_y_prev = widest_y
                widest_y = zxy[i,2]
                x0 = zxy[i,1]
                continue
        
        # add any remaining area in the trailing segment if less than a "del_x" in width
        if x0 != zxy[zxy.shape[0]-1,1] and x0 + del_x > zxy[zxy.shape[0]-1,1]:
            tot_area += (widest_y + widest_y_prev) * 0.5 * (zxy[zxy.shape[0]-1,1] - x0)
        
        tot_area *= 2

        self.prev_area = tot_area

        return tot_area