import math

from py_lopa.calcs.dippr_eqns import eqn_107_by_T
from py_lopa.calcs.consts import Consts
from py_lopa.classes.solver import Solver

r = Consts.R_PA_M3_KMOL_DEGK

def isenthalpic_find_t2(cp_consts_j_kmol_k, hvap_j_kmol, t_sat_deg_k, t1_deg_k, p1_pa, p2_pa):

    # delta s = (integCpdt/T | from T1 to T2) + deltaHvap / Tsat - R * ln(P1 / P2)
    # isentropic -> detla s = 0
    # use secant method / bisection to solve for T2
    
    enth_term_t1 = eqn_107_by_T(consts=cp_consts_j_kmol_k, t=t1_deg_k, integrated=True)
    
    h_vap_term = hvap_j_kmol / t_sat_deg_k
    press_term = r * math.log(p1_pa / p2_pa)

    args = {
        'enth_term_t1': enth_term_t1,
        'h_vap_term': h_vap_term,
        'press_term': press_term,
        't_sat_deg_k': t_sat_deg_k,
        'cp_consts': cp_consts_j_kmol_k,
    }

    t2_deg_k = 200

    solver = Solver(arg_to_vary=t2_deg_k, fxn_to_solve=entropy_balance_solver, args=args, target=0)

    # bisect used if secant fails.  internal to solver method
    solver.set_bisect_parameters(lower_limit=0.001, upper_limit=t1_deg_k, output_increases_as_input_increases=True)

def entropy_balance_solver(t2_deg_k, args):

    enth_term_t1 = args['enth_term_t1']
    h_vap_term = args['h_vap_term']
    press_term = args['press_term']
    t_sat_deg_k = args['t_sat_deg_k']
    cp_consts = args['cp_consts']

    enth_term_t2 = eqn_107_by_T(consts=cp_consts, t=t2_deg_k, integrated=True)

    if t2_deg_k > t_sat_deg_k:
        h_vap_term = 0

    return enth_term_t2 - enth_term_t1 + h_vap_term - press_term

